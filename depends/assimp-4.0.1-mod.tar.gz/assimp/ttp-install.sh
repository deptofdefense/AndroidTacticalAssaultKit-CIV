#!/bin/bash

cp build-android-x86/libjassimp.so ../trunk/ATAKMapEngine/libs/x86/libjassimp.so
cp build-android-arm/libjassimp.so ../trunk/ATAKMapEngine/libs/armeabi-v7a/libjassimp.so
