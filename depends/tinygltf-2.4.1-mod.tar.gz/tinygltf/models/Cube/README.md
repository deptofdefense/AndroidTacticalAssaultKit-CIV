License: Donated by Norbert Nopper for glTF testing.

https://github.com/KhronosGroup/glTF-Sample-Models/tree/master/2.0/Cube

