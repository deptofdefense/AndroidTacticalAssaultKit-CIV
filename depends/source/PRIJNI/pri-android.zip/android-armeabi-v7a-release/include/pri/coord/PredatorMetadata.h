#ifndef _PREDATOR_METADATA_H_
#define _PREDATOR_METADATA_H_

#include <iostream>
#include <sstream>
#include <string>
#include <stdio.h>
#include "DecimalCoordinate.h"

using namespace std;

class PredatorMetadata
{
public:
	static const int UNKNOWN_COORD_SYS = 0;
	static const int GEOD_WGS84_COORD_SYS = 1;
	static const int GEOC_WGS84_COORD_SYS = 2;
	static const int NONE_COORD_SYS = 3;

private:
	int frameNum;
	int userTimeStamp;
	DecimalCoordinate UL, UR, LL, LR;
	DecimalCoordinate center;
	DecimalCoordinate device;
	string startDateTime;		// UTC time is in the ISO8601 Basic format "YYYYMMDDThhmmss"
	string classification;
	string coordSys;
	string deviceNumber;
	string episodeNumber;
	string eventStartDate;		// UTC time in the ISO8601 Basic format "YYYYMMDDThhmmss"
	string sourceDeviceName;
	string xmlUserTimeStamp;
	float angleToNorth;
	float deviceAltitude;
	float fovHorz;
	float fovVert;
	float obliquityAngle;
	float platformHeading;
	float platformPitch;
	float platformRoll;
	float sensorRoll;
	float slantRange;
	float targetWidth;

public:
	PredatorMetadata(void);
	~PredatorMetadata(void);
	int getFrameNum();
	DecimalCoordinate getUL(void);
	DecimalCoordinate getUR(void);
	DecimalCoordinate getLR(void);
	DecimalCoordinate getLL(void);
	DecimalCoordinate getCenter(void);
	string getStartDateTime(void);
	string getClassification(void);
	string getCoordSys(void);
	string getDeviceNumber(void);
	string getEpisodeNumber(void);
	string getEventStartDate(void);
	string getXmlUserTimeStamp(void);
	string getSourceDeviceName(void);
	float getAngleToNorth(void);
	float getDeviceAltitude(void);
	float getFOVHorz(void);
	float getFOVVert(void);
	float getObliquityAngle(void);
	float getPlatformHeading(void);
	float getPlatformPitch(void);
	float getPlatformRoll(void);
	float getSensorRoll(void);
	float getSlantRange(void);
	float getTargetWidth(void);
	int getUserTimeStamp(void);
	DecimalCoordinate getDevice(void);
	void setFrameNum(int val);
	void setUL(double lat, double lon);
	void setUR(double lat, double lon);
	void setLR(double lat, double lon);
	void setLL(double lat, double lon);
	void setUL(double lat, double lon, double elev);
	void setUR(double lat, double lon, double elev);
	void setLR(double lat, double lon, double elev);
	void setLL(double lat, double lon, double elev);
	void setCenter(double lat, double lon, double elev);
	void setDevice(double lat, double lon);
	void setStartDateTime(string val);
	void setClasssification(string classification);
	void setCoordSys(string coordSys);
	void setAngleToNorth(float angleToNorth);
	void setDeviceAltitude(float deviceAltitude);
	void setDeviceNumber(string deviceNumber);
	void setEpisodeNumber(string episodeNumber);
	void setEventStartDate(string eventStartDate);
	void setFOVHorz(float fovHorz);
	void setFOVVert(float fovVert);
	void setObliquityAngle(float obliquityAngle);
	void setPlatformHeading(float platformHeading);
	void setPlatformPitch(float platformPitch);
	void setPlatformRoll(float platformRoll);
	void setSensorRoll(float sensorRoll);
	void setSlantRange(float slantRange);
	void setUserTimeStamp(int userTimeStamp);
	void setSourceDeviceName(string sourceDeviceName);
	void setTargetWidth(float targetWidth);
	void setXmlUserTimeStamp(string xmlUserTimeStamp);
};

#endif	// _PREDATOR_METADATA_H_
