#ifndef _UTILS_
#define _UTILS_

#include <math.h>
#include <algorithm>
#include <string>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cctype>
#include "CommonCoordException.h"
#include "DecimalCoordinate.h"
//#include "LexicalCastException.h"
//#include <import/except.h>
//#include <exception>

/*************************** Version: trunk ***************************/

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////

namespace iai
{

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

class COMMONCPPCOORDAPI Utils
{
public:

	inline static double stringToDouble(std::string const& str) //throw (CommonCoordException)
	{
		std::istringstream ss(str);

		double x;
		char c;
		if ( !(ss >> x) || ss.get(c) ) {
			throw CommonCoordException("Utils::stringToDouble conversion exception");
		}
		return x;
	}

	inline static int stringToInt(std::string const& str) //throw (CommonCoordException)
	{
		std::istringstream ss(str);

		int x;
		char c;
		if ( !(ss >> x) || ss.get(c) ) {
			throw CommonCoordException("Utils::stringToInt conversion exception");
			//throw except::BadCastException("stringToInt(\"" + str + "\")");
			//throw LexicalCastException("stringToInt(\"" + str + "\")");
		}
		return x;
	}

	inline static std::string toString(double x) //throw (CommonCoordException)
	{
		std::ostringstream o;
		if (!(o << std::setiosflags(std::ios::fixed) << std::setprecision(8) << x)) {
			throw CommonCoordException("Utils::toString(double) conversion exception");
		}
		return o.str();
	}

	inline static std::string toString(int x) //throw (CommonCoordException)
	{
		std::ostringstream o;
		if (!(o << x)) {
			throw CommonCoordException("Utils::toString(int) conversion exception");
		}
		return o.str();
	}

	inline static std::string trimStr(const std::string& src, const std::string& c = " \r\n")
	{
		int p2 = src.find_last_not_of(c);
		if (p2 == std::string::npos) {
			return std::string();
		}
		int p1 = src.find_first_not_of(c);
		if (p1 == std::string::npos) {
			p1 = 0;
		}
		return src.substr(p1, (p2-p1)+1);
	}

	inline static void toUpper(std::string& src)
	{
		std::transform(src.begin(), src.end(), src.begin(), ::toupper);
	}

	inline static void toUpper(char& c)
	{
		toupper(c);
	}

	inline static double toFeet(double xInMeters)
	{
		return (xInMeters * 3.2808399);
	}

	inline static double toMeters(double xInFeet)
	{
		return (xInFeet * 0.3048);
	}

	inline static int round(double x)
	{
		return int(x > 0.0 ? x + 0.5 : x - 0.5);
	}

	inline static double toRadians(double angdeg)
	{
		return angdeg / 180.0 * M_PI;
	}

	inline static double toDegrees(double angrad)
	{
		return angrad * 180.0 / M_PI;
	}

	static bool parseIGEOLO(std::string igeolo, std::string icords);
	static bool parseIGEOLO(std::string igeolo, std::string icords,
		DecimalCoordinate* ul, DecimalCoordinate* ur,
		DecimalCoordinate* lr, DecimalCoordinate* ll);

};

//struct ci_char_traits : public char_traits<char>
//	// just inherit all the other functions
//	//  that we don't need to override
//{
//	static bool eq( char c1, char c2 )
//	{ return toupper(c1) == toupper(c2); }
//
//	static bool ne( char c1, char c2 )
//	{ return toupper(c1) != toupper(c2); }
//
//	static bool lt( char c1, char c2 )
//	{ return toupper(c1) <  toupper(c2); }
//
//	static int compare( const char* s1,
//		const char* s2,
//		size_t n ) {
//			return _memicmp( s1, s2, n );
//			// if available on your compiler,
//			//  otherwise you can roll your own
//	}
//
//	static const char*
//		find( const char* s, int n, char a ) {
//			while( n-- > 0 && toupper(*s) != toupper(a) ) {
//				++s;
//			}
//			return s;
//	}
//};
//
//typedef basic_string<char, ci_char_traits> ci_string;
}
#endif // _UTILS_
