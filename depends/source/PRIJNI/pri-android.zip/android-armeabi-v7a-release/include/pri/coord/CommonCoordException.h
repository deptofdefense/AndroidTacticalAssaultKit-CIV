#ifndef _COMMONCOORDEXCEPTION_H_
#define _COMMONCOORDEXCEPTION_H_

/*************************** Version: trunk ***************************/

#include <stdexcept>
#include <iostream>
#include <string.h>

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////
namespace iai
{

class COMMONCPPCOORDAPI CommonCoordException : public std::exception
{
public:
	CommonCoordException();

	~CommonCoordException() throw () {}

	CommonCoordException(const std::string& message)
		: mMessage(message) {}

	void printMessage() { std::cout << mMessage << std::endl; }
	std::string getMessage() { return mMessage; }

protected:
    // The name of the message the exception was thrown
    std::string mMessage;

};
}

#endif // _COMMONCOORDEXCEPTION_H_
