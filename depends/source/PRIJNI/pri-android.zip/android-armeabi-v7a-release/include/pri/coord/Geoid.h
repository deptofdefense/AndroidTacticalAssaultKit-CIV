#ifndef _COMMON_GEOID_
#define _COMMON_GEOID_

/*************************** Version: trunk ***************************/

#include <iostream>

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////

using namespace std;

namespace iai
{

class COMMONCPPCOORDAPI Geoid{
public:
	static Geoid* getInstance(string egm96File, string corrcoefFile);

	double getUndulation(double inLat, double inLon);

private:
	Geoid();
	~Geoid();
	Geoid(string egm96File, string corrcoefFile);
	Geoid(const Geoid &oldGeoid);
	Geoid& operator=(const Geoid &oldGeoid);

	bool dhcsin(long nmax, string egmFile);
	bool radgra(double flat, double flon, double ht);
	bool legfdn(int m, double theta, int nmx, long iflag);
	bool dscml(double rlon);
	double hundu(double ang);

	static Geoid* static_instance;
	static string current_egm_file;
	static string current_coeff_file;

	long nmax;

	bool initialized;

	double rj2;
	double rj4;
	double rj6;
	double flatl;

	double rlat;
	double rlon;
	double rlat1;
	double re;
	double gr;
	double haco;

	long iflag;

	double *hc;
	double *hs;
	double *cc;
	double *cs;

	double *rleg;
	double *dleg;
	double *rlnn;
	double *p;

	double *sinml;
	double *cosml;

	static double PI;
	static double DEG_PER_RAD;
	static double CONST_F;
	static double CONST_E2;
	static double CONST_GEQT;
	static double CONST_K;
	static double CONST_A;
	static double CONST_GM;

};

}

#endif