#ifndef _DECIMALCOORDINATE_H_
#define _DECIMALCOORDINATE_H_

/*************************** Version: trunk ***************************/

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////

#include <string>
#include <sstream>
namespace iai
{

class COMMONCPPCOORDAPI DecimalCoordinate
{
private:
	double x, y, z;

public:
	DecimalCoordinate(void);
	DecimalCoordinate(double lat, double lon);
	DecimalCoordinate(double lat, double lon, double elev);
	~DecimalCoordinate();
	double getLat(void);	// returns y
	double getLon(void);	// returns x
	double getElev(void);	// returns z
	void setLat(double val);	// sets y
	void setLon(double val);	// sets x
	void setElev(double val);	// sets z
	std::string toXMLString(int ind);	// returns string representation of element at position i
	double distance(DecimalCoordinate *dc);

	static double distance(double lat1, double lon1, double lat2, double lon2);
};
}
#endif	// _DECIMAL_COORDINATE_H_
