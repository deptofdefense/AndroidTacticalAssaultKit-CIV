#ifndef _REG_COORD_H_
#define _REG_COORD_H_

/*************************** Version: trunk ***************************/

#include "DecimalCoordinate.h"

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////

namespace iai
{

class COMMONCPPCOORDAPI RegCoord
{
public:
	// Members
	DecimalCoordinate * coord;
	bool isLinked;

	// Constructors
	RegCoord(void);
	RegCoord(DecimalCoordinate * coord);
	RegCoord(double lat, double lon);
	~RegCoord(void);

	// Functions
	DecimalCoordinate * getCoord();
	double getLat(void);	// returns y
	double getLon(void);	// returns x
	double getElev(void);	// returns z
	void setCoord(DecimalCoordinate * coord);
	void setLat(double val);	// sets y
	void setLon(double val);	// sets x
	void setElev(double val);	// sets z
};

}

#endif	// _REG_COORD_H_
