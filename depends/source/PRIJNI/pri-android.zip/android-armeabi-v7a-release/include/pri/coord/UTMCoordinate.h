#ifndef _UTMCOORDINATE_H_
#define _UTMCOORDINATE_H_


//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////

namespace iai
{

class COMMONCPPCOORDAPI UTMCoordinate
{
public:

	int zone;
	char zoneCode;
	bool southernHemisphere;
	double easting;
	double northing;

	UTMCoordinate(void);
	UTMCoordinate(UTMCoordinate* utmCoordinate);
	~UTMCoordinate(void);

	bool inSouthernHemisphere(void);
};

}

#endif // _UTMCOORDINATE_H_