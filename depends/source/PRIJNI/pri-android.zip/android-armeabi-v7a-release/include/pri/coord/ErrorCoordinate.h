#ifndef _ERROR_COORDINATE_H_
#define _ERROR_COORDINATE_H_

/*************************** Version: trunk ***************************/

#include "DecimalCoordinate.h"

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////
namespace iai
{

class COMMONCPPCOORDAPI ErrorCoordinate : public DecimalCoordinate
{
private:
	double ce, le;

public:
	ErrorCoordinate(void);
	ErrorCoordinate(double lat, double lon);
	ErrorCoordinate(double lat, double lon, double elev);
	ErrorCoordinate(double lat, double lon, double elev, double ce, double le);

	double getCE(void);
	double getLE(void);

	void setCE(double val);
	void setLE(double val);

};
}
#endif	// _ERROR_COORDINATE_H_
