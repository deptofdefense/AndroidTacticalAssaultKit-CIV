#ifndef _MGRS_H_
#define _MGRS_H_

#include "MGRSCoordinate.h"
#include "DecimalCoordinate.h"

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////

// ************************************************************
// MGRS
//
// Following the same pattern for function input/output
// as the UTM class. It is assumed the user allocates 
// all incoming/outgoing pointers
//
// Mostly copied from the Java version of MGRS
// *************************************************************

namespace iai
{

class COMMONCPPCOORDAPI MGRS
{
public:
	// Need to confirm I'm getting the dimensions right
	static const char EASTING[7][9];
	static const char NORTHING[2][20];
	static const char ZONES[20];

	MGRS(void);
	~MGRS(void);


	// returns -1 on failure, 0 on success
	static int toDecimal(MGRSCoordinate * mgrs, int datum, DecimalCoordinate * dc);
	
	// returns -1 on failure, 0 on success	
	static int toMGRS(DecimalCoordinate * dc, int datum, MGRSCoordinate * mgrs);

	// Expects a string in the format specified by the NITF 2500c spec
	// Example: 01CDM4186816915
	static void parseMGRSString(std::string input, MGRSCoordinate * mgrs);


private:

	static const int easting_length = 9;
	static const int northing_length = 20;
	static const int num_zones = 20;
	static const int utmrowperiod = 20;
	static const int maxutmSrow = 100;

	static int computeSet(int zone);
	static int UTMRow(int iband, int icol, int irow);

};

}

#endif // _UTM_H_