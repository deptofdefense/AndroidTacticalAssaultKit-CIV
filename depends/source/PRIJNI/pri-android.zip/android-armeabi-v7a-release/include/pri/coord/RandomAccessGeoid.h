#ifndef _RANDOM_ACCESS_GEOID_H
#define _RANDOM_ACCESS_GEOID_H

#include <iostream>
#include <fstream>
#include <string>

/*************************** Version: trunk ***************************/

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////

using namespace std;

namespace iai
{

class COMMONCPPCOORDAPI RandomAccessGeoid{
public:
	RandomAccessGeoid(string filename);
	RandomAccessGeoid(const unsigned char* geoidData, const unsigned int length);
	void setDataFile(string datafile);
	double getUndulation(double lat, double lon);
private:
	RandomAccessGeoid();
	string datafile;
	const unsigned char* geoidData;	// does not own pointer data
	const unsigned int length;
	ifstream data;
	double readValue(ifstream &data, double gridlat, double gridlon);
	double readValue(const unsigned char* geoidData, double gridlat, double gridlon);
};

}

#endif