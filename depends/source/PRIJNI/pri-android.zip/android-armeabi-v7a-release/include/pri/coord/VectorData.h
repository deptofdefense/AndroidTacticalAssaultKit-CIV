#ifndef _VECTOR_DATA_H_
#define _VECTOR_DATA_H_

/*************************** Version: trunk ***************************/

#include "DLinkedList.h"
#include "DecimalCoordinate.h"
#include "PixelCoordinate.h"
#include "RegCoord.h"

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////


/// Class storing a vector of geographic or pixel points.
/*************************************************************************//**
 * Class storing a vector of geographic or pixel points.  Also has utility
 * fields for storing shifts in vector data.
 *
 * VectorData assumes ownership of the DLinkedLists provided to it and will
 * delete them if destroyed while holding them.
 *****************************************************************************/

namespace iai
{

class COMMONCPPCOORDAPI VectorData
{
public:
	// Members
	string uid;
	DLinkedList<DecimalCoordinate> * coords;
	DLinkedList<PixelCoordinate> * points;
	bool connected;
	bool closed;

	DLinkedList<RegCoord> * regCoords;

	float shiftX;
	float shiftY;

	// Constructors
	VectorData(void);
	VectorData(DLinkedList<DecimalCoordinate> * coords, bool connected, bool closed);
	~VectorData(void);

	// Functions
	bool isClosed();
	bool isConnected();
	string toXML();

	bool setRegCoords(DLinkedList<RegCoord> * rc);
	bool addRegCoords(RegCoord * rc);
};

}

#endif	// _VECTOR_DATA_H_
