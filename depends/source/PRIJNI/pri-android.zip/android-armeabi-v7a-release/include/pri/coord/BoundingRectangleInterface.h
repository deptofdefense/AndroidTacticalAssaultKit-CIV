#ifndef BOUNDING_RECTANGLE_INTERFACE_H_
#define BOUNDING_RECTANGLE_INTERFACE_H_

/*************************** Version: trunk ***************************/

#include "BoundingRectangle.h"
#include "DLinkedList.h"
#include "GeoQuad.h"
#include "Quad.h"

#include <string>

using namespace std;
namespace iai
{

class BoundingRectangleInterface
{
public:
	BoundingRectangleInterface();
	~BoundingRectangleInterface();
	static DLinkedList<GeoQuad> * getGeoQuadsFromFile(string xmlFile);
	static Quad calculateBoundingRectangle(DLinkedList<PixelCoordinate> * pixCoords);
	static Quad calculateBoundingRectangle(DLinkedList<Quad> * pixQuads);
	static GeoQuad calculateBoundingRectangle(DLinkedList<DecimalCoordinate> * geoCoords);
	static GeoQuad calculateBoundingRectangle(DLinkedList<GeoQuad> * geoQuads);

};
}
#endif