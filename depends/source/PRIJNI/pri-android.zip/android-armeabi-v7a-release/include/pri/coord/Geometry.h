#ifndef GEOMETRY_H_
#define GEOMETRY_H_

/*************************** Version: trunk ***************************/

#include "Quad.h"
#include "PixelCoordinate.h"
#include "DecimalCoordinate.h"
#include "DLinkedList.h"
#include "GeoQuad.h"
#include "math.h"
#include <iostream>
#include <vector>

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////

namespace iai
{

// Definitions
#ifndef M_PI
#define M_PI 3.141592653589793
#endif
#define TOL 0.0000001 // default geometry tolerance for coordinate values being equal

class COMMONCPPCOORDAPI Geometry
{
public:

	static DLinkedList<PixelCoordinate> * getAllIntersections(Quad A, Quad B, double tolerance = TOL);
	static DLinkedList<PixelCoordinate> * getAllIntersections(DLinkedList<PixelCoordinate> * coordsA, DLinkedList<PixelCoordinate> * coordsB, double tolerance = TOL);
	static DLinkedList<PixelCoordinate> * getAllPolyLineIntersections(DLinkedList<PixelCoordinate> * polyCoords, DLinkedList<PixelCoordinate> * lineCoords, double tolerance = TOL);
	static double * cornerCrossProduct(PixelCoordinate * a, DLinkedList<PixelCoordinate> * BList);
	static double crossProduct(PixelCoordinate * a, PixelCoordinate * b, PixelCoordinate * c);
	static double dotProduct(PixelCoordinate * A, PixelCoordinate * B, PixelCoordinate * C);
	static DLinkedList<PixelCoordinate> * trimCoordinates(DLinkedList<PixelCoordinate> * c);
	static DLinkedList<PixelCoordinate> * orderCoordinates(DLinkedList<PixelCoordinate> * c);
	static double calculateAngle(PixelCoordinate * a, PixelCoordinate * b, PixelCoordinate * c);
	static DLinkedList<PixelCoordinate> * getIntersections(PixelCoordinate * a1, PixelCoordinate * a2, PixelCoordinate * b1, PixelCoordinate * b2, double tolerance = TOL);
	static bool isPointInside(PixelCoordinate * point, GeoQuad * polygon);
	static bool polygonsIntersecting( vector<DecimalCoordinate>& A,  vector<DecimalCoordinate>& B);
	static void getMBR(const vector<DecimalCoordinate>& points, vector<DecimalCoordinate>& mbr);
	static bool doesOverlap(const vector<DecimalCoordinate>& a, const vector<DecimalCoordinate>& b);
	static bool doLineSegmentsIntersect( DecimalCoordinate& a0,  DecimalCoordinate& a1,
				 DecimalCoordinate& b0,  DecimalCoordinate& b1);
	static double orientedArea(DecimalCoordinate& p, DecimalCoordinate& a, DecimalCoordinate& b);
	static bool isPointInsidePolygon(PixelCoordinate * pt, DLinkedList<PixelCoordinate> * poly);
	static bool isPointInsidePolygon(DecimalCoordinate pt, vector<DecimalCoordinate> poly);
	static bool pointInPoly(double x, double y, double X[], double Y[],int n);
    static double getBearing(DecimalCoordinate p1, DecimalCoordinate p2);
	static double getPercentCoverage(DLinkedList<PixelCoordinate> * coordsA, DLinkedList<PixelCoordinate> * coordsB, double tolerance = TOL);
	static double getPercentCoverage(Quad A, Quad B, double tolerance = TOL);
	static double getPolygonArea(DLinkedList<PixelCoordinate> * polygon, bool returnSigned = false);
};

}

#endif