#ifndef _GEO_QUAD_H_
#define _GEO_QUAD_H_

/*************************** Version: trunk ***************************/

#include "DecimalCoordinate.h"
#include "Quad.h"
#include "PixelCoordinate.h"
#include <vector>

using std::vector;

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////

namespace iai
{

class COMMONCPPCOORDAPI GeoQuad 
{
private:
	DecimalCoordinate UL;
	DecimalCoordinate UR;
	DecimalCoordinate LR;
	DecimalCoordinate LL;

	static const int UL_IND;
	static const int UR_IND;
	static const int LR_IND;
	static const int LL_IND;

public:

	GeoQuad(void);
	GeoQuad(DecimalCoordinate UL, DecimalCoordinate UR, DecimalCoordinate LR, DecimalCoordinate LL);
	GeoQuad(GeoQuad * targ);
	GeoQuad(double latUL, double lonUL, double latUR, double lonUR,
			double latLR, double lonLR, double latLL, double lonLL);
	~GeoQuad(void);

	void copy(GeoQuad * src, GeoQuad * dst);
	vector<PixelCoordinate> toVector();		// used PixelCoordinate instead of Point3d
	vector<DecimalCoordinate> toGeoVector();
	Quad toQuad();

	// Getters/Setters
	DecimalCoordinate getUL();
	void setUL(DecimalCoordinate ul);
	DecimalCoordinate getUR();
	void setUR(DecimalCoordinate ur);
	DecimalCoordinate getLR();
	void setLR(DecimalCoordinate lr);
	DecimalCoordinate getLL();
	void setLL(DecimalCoordinate ll);

	static int getULIndex();
	static int getURIndex();
	static int getLRIndex();
	static int getLLIndex();
};

}

#endif	// _GEO_QUAD_H_
