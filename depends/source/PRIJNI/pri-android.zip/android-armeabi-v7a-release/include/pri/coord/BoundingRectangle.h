#ifndef BOUNDING_RECTANGLE_H_
#define BOUNDING_RECTANGLE_H_

/*************************** Version: trunk ***************************/

//#include "stdafx.h"
//#include "windows.h"
#include "LinearBestFitType.h"
#include "PixelCoordinate.h"
#include "GeoQuad.h"
#include "Quad.h"
#include "DecimalCoordinate.h"

#include <string>

using namespace std;

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////
namespace iai
{

class COMMONCPPCOORDAPI BoundingRectangle
{
private:
	static const double radianThreshold;

public:
	BoundingRectangle();
	~BoundingRectangle();
	static DLinkedList<PixelCoordinate> * createBoundingRectangle(DLinkedList<PixelCoordinate> * points);
	static DLinkedList<DecimalCoordinate> * createBoundingRectangle(DLinkedList<DecimalCoordinate> * coords);
	static Quad findPixelBoundingRectangle(DLinkedList<PixelCoordinate> * pixelCoords);
	static GeoQuad findBoundingRectangle(DLinkedList<DecimalCoordinate> * geoCoords);
	static DLinkedList<PixelCoordinate> * rotatePixelPoints(DLinkedList<PixelCoordinate> * pixelCoords, double rad, bool isClockwise);
	static DLinkedList<DecimalCoordinate> * rotateCoordinates(DLinkedList<DecimalCoordinate> * geoCoord, double rad, bool isClockwise);
	static double calculateArea(DLinkedList<PixelCoordinate> * pixelCoords);
	static double calculateArea(DLinkedList<DecimalCoordinate> * geoCoords);
	static GeoQuad uprightBoundingRectangle(GeoQuad quad);
};

}
#endif