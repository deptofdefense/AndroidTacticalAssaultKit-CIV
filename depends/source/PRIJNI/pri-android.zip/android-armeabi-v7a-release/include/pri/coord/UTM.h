#ifndef _UTM_H_
#define _UTM_H_

#include "UTMCoordinate.h"
#include "DecimalCoordinate.h"

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////

#define DATUM_NUM 10

namespace iai
{

class COMMONCPPCOORDAPI UTM
{
public:

	UTM(void);
	~UTM(void);

	static int WGS84;
	static int WGS72;
	static int WGS66;
	static int WGS60;
	static int GRS80;
	static int GRS75;
	static int GRS67;
	static int TOKYO;
	static int AUSTRALIAN;
	static int NAD83;

	static double n[DATUM_NUM];
	static double alpha[DATUM_NUM];
	static double beta[DATUM_NUM];
	static double gamma[DATUM_NUM];
	static double delta[DATUM_NUM];
	static double epsilon[DATUM_NUM];
	static double alpha_[DATUM_NUM];
	static double beta_[DATUM_NUM];
	static double gamma_[DATUM_NUM];
	static double delta_[DATUM_NUM];
	static double epsilon_[DATUM_NUM];
	static double ep2[DATUM_NUM];

	static void toUTM(double lat, double lon, int datum, UTMCoordinate* utm);
	static void toDecimal(UTMCoordinate* utm, int datum, DecimalCoordinate* dc);
	static int computeZone(double lat, double lon);
	static char computeUTMLetterDesignator(double lat);
	static double* convertTMToLatLon(double x, double y, double cMeridian, int datum);
	static double* convertLatLonToTM(double lat, double lon, int zone, int datum);
	static double computeArcLengthOfMeridian(double lat, int datum);
	static double computeUTMCentralMeridian(int zone);
	static double computeEccentricityPS(int datum);
	static double footprintLatitude(double northing, int datum);

	static double computeN(int datum);
	static double computeAlpha(int datum);
	static double computeBeta(int datum);
	static double computeGamma(int datum);
	static double computeDelta(int datum);
	static double computeEpsilon(int datum);
	static double computeAlpha_(int datum);
	static double computeBeta_(int datum);
	static double computeGamma_(int datum);
	static double computeDelta_(int datum);
	static double computeEpsilon_(int datum);

	// Expects a string in the format specified by the NITF 2500c spec
	// 114319193954895
	static void parseUTMString(std::string input, UTMCoordinate * utm);

private:

	static double equatorialRadius[DATUM_NUM];
	static double polarRadius[DATUM_NUM];

	static double UTMScaleFactor;

};

}

#endif // _UTM_H_