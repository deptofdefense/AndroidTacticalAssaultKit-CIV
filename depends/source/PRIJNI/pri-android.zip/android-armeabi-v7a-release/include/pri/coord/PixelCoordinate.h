#ifndef _PIXEL_COORDINATE_H_
#define _PIXEL_COORDINATE_H_

/*************************** Version: trunk ***************************/

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////

namespace iai
{

class COMMONCPPCOORDAPI PixelCoordinate
{
private:
	double x, y, z;

public:
	PixelCoordinate(void);
	PixelCoordinate(double x, double y);
	PixelCoordinate(double x, double y, double z);
	double getX(void);
	double getY(void);
	double getZ(void);
	void setX(double val);
	void setY(double val);
	void setZ(double val);
};

}

#endif	// _PIXEL_COORDINATE_H_