#ifndef _PREDATOR_METADATA_UTILS_H_
#define _PREDATOR_METADATA_UTILS_H_

#include "DLinkedList.h"
#include "PredatorMetadata.h"
#include <string>

using namespace std;

class PredatorMetadataUtils
{
public:
	PredatorMetadataUtils(void);
	~PredatorMetadataUtils(void);

	static int findMostRecentFrameIndex(DLinkedList<PredatorMetadata>* metadata,
										int videoFrame, int startingIndex = 0);

	static DLinkedList<PredatorMetadata> * parseXMLFile(string xmlFile);
};

#endif	// _PREDATOR_METADATA_UTILS_H_
