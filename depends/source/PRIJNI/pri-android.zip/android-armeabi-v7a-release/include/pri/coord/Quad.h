#ifndef _QUAD_H_
#define _QUAD_H_

/*************************** Version: trunk ***************************/

#include "PixelCoordinate.h"

//////////////////// DLL Import/Export ////////////////////////////////////////
#if defined _WIN32 || defined __CYGWIN__
#if defined(COMMONCPP_COORD_EXPORTS)	 // inside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllexport)
#elif defined(COMMONCPP_COORD_IMPORTS)// outside DLL
#   define COMMONCPPCOORDAPI   __declspec(dllimport)
#else
#   define COMMONCPPCOORDAPI			 // including code directly into project
#endif  // COMMONCPP_COORD_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(COMMONCPP_COORD_EXPORTS) // inside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#else // outside DLL
#   define COMMONCPPCOORDAPI  __attribute__ ((visibility("default")))
#endif  // COMMONCPP_COORD_EXPORTS
#else
#define COMMONCPPCOORDAPI
#endif
#endif
////////////////// End DLL Import/Export //////////////////////////////////////

namespace iai
{

class COMMONCPPCOORDAPI Quad
{
private:
	PixelCoordinate UL;
	PixelCoordinate UR;
	PixelCoordinate LR;
	PixelCoordinate LL;

public:
	Quad(void);
	Quad(PixelCoordinate UL,	PixelCoordinate UR, PixelCoordinate LR, PixelCoordinate LL);
	Quad(Quad * targ);
	Quad(double xUL, double yUL, double xUR, double yUR,
         double xLR, double yLR, double xLL, double yLL);
	~Quad(void);

	void copy(Quad * src, Quad * dst);

	// Getters/Setters
	PixelCoordinate getUL();
	void setUL(PixelCoordinate ul);
	PixelCoordinate getUR();
	void setUR(PixelCoordinate ur);
	PixelCoordinate getLR();
	void setLR(PixelCoordinate lr);
	PixelCoordinate getLL();
	void setLL(PixelCoordinate ll);

};

}

#endif	// _QUAD_H_
