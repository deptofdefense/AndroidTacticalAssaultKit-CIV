#ifndef _IAI_ECEF_H_
#define _IAI_ECEF_H_

#include "newmat.h"

namespace iai
{

    class ECEFRay
    {
    public:
        NEWMAT::RowVector pt;
        NEWMAT::RowVector dir;

        ECEFRay() : pt(3), dir(3) { pt = 0.0; dir = 0.0; }
        ECEFRay(const NEWMAT::RowVector& pointIn,
                const NEWMAT::RowVector& directionIn) :
            pt(pointIn), dir(directionIn)
        {
        }

        ECEFRay(double ptX, double ptY, double ptZ,
                double dirX, double dirY, double dirZ);

        void set(NEWMAT::RowVector& point, NEWMAT::RowVector& direction);
        void get(NEWMAT::RowVector& point, NEWMAT::RowVector& direction) const;

        void calcPointOfClosestApproach(const ECEFRay& otherRay,
                                        NEWMAT::RowVector& intersectionPoint,
                                        NEWMAT::RowVector& minDistanceVector);

        void computeIntersectionOfPlanes(double dudx, double dudy, double dydz, double u,
                                         double dvdx, double dvdy, double dvdz, double v);

        void groundIntersection(double altitude, NEWMAT::RowVector &gndPtIntersection);

        void computePointOfClosestApproach(const ECEFRay& otherRay,
                                           NEWMAT::RowVector& intersectionPoint,
                                           NEWMAT::RowVector& minDistanceVector);

        static NEWMAT::RowVector cross(const NEWMAT::RowVector& a,
                                       const NEWMAT::RowVector& b);
    };

} // namespace iai
#endif