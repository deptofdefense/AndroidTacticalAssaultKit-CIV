#ifndef PAGAN_COMMONMODEL_H
#define PAGAN_COMMONMODEL_H
#include <iostream>
#include <cmath>
#include "math.h"
#include "newmat.h"
#include "ErrorCoordinate.h"

using namespace NEWMAT;

class CommonModel
{
public:
    const static double PI;
    const static double f;
    const static double ep2;
    const static double e2;
    const static double flattening;
    const static double semiMajorAxis;
    const static double M_PER_FT;
    const static double M2FT;
    const static double FT2M;
    const static double aFt;
    const static double LARGE;
    const static double DLAT_MAX;
    const static double DZA_MAX;
    const static double RAD2DEG;
    const static double DEG2RAD;

    CommonModel();        // constructor
    ~CommonModel();

    static RowVector geodeticToGeocentric(RowVector inLPH);
    static RowVector geodeticToGeocentricMetric(RowVector inLPHMeters);
    static RowVector geocentricToGeodetic(RowVector inXYZ);
    static RowVector geocentricToGeodeticMetric(RowVector inXYZMeters);

    static ColumnVector azElToENU(const double& azDeg, const double& elDeg);
    static ColumnVector enuToECEF(const double& latDeg, const double& lonDeg,
                                  const ColumnVector& enu);
    static ColumnVector ecefToENU(const double& latDeg, const double& lonDeg,
                                  const ColumnVector& ecef);

    static void calculatePositionError(const ColumnVector& R, Matrix &Sdd,
            double &ce90, double &le90, Matrix &groundCovarianceENU);
    static ColumnVector cross(const ColumnVector& a, const ColumnVector& b);
    static double cep_doc(const Matrix& inMatrix);
    static double getDistanceFeet(iai::ErrorCoordinate& coord1, iai::ErrorCoordinate& coord2);
    static double getDistanceMeters(iai::ErrorCoordinate& coord1, iai::ErrorCoordinate& coord2);
    static double calcJulianDay(int year, int month, int day);
    static double calcJulianCentury(double julianDay);
    static double calcSunGeometricMeanLongitude(double julianCentury);
    static double calcSunGeometricMeanAnomaly(double julianCentury);
    static double calcEarthOrbitEccentricity(double julianCentury);
    static double calcEquationOfSunCenter(double julianCentury);
    static double calcSunTrueLongitude(double julianCentury);
    static double calcSunApparentLongitude(double julianCentury);
    static double calcMeanObliquityOfEcliptic(double julianCentury);
    static double calcObliquityCorrection(double julianCentury);
    static double calcSunDeclination(double julianCentury);
    static double calcEquationOfTime(double julianCentury);

    static void calSunAngles(int year, int month, int day,
                             int hour, int minute, int second,
                             double latitudeDeg, double longitudeDeg,
                             double &azimuth, double &elevation);

    static void calcSunAngles(int year, int month, int day,
                              int hour, int minute, int second,
                              double latitudeDeg, double longitudeDeg,
                              double &azimuth, double &elevation);

private:
    static RowVector geodeticToECEF(RowVector inLPH, bool isMetric);
    static RowVector ecefTogeodetic(RowVector inXYZ, bool isMetric);
};
#endif
