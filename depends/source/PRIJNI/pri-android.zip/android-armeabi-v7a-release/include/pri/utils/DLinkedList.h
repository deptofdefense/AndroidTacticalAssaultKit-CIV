#ifndef _DLINKEDLIST_H
#define _DLINKEDLIST_H

/*************************** Version: trunk ***************************/

#include <stdlib.h>
#include <iostream>
#include <string>
#include "Node.h"

using namespace std;

/// DLinkedList - Doubly linked list (DLL) template
/*************************************************************************//**
 * Implements a generic doubly linked list.  A current pointer is available
 * for use in looping through the linked list in linear time, similar to 
 * an array.  The default destructor for the class T will be used to destroy
 * objects in the linked list that are destroyed with either ~DLinkedList() or
 * clear(), unless a function pointer has been specified and passed into
 * dtor (either using the DLinkedList( void (*dtorFP)(T ** obj) ) ctor or
 * using set_dtor(), in which case the function pointed to by dtor will be
 * used to destroy the objects of class T held in each node.  Data in a node
 * that is popped off is returned to the user and it is their responsibility
 * to destroy it.  Otherwise the DLinkedList assumes ownership of the data.
 *****************************************************************************/
template <class T>
class DLinkedList
{
	// Variables
private:
	Node<T>* head;			   ///< Head node of linked list
	Node<T>* tail;			   ///< Tail node of linked list
	Node<T>* current;		   ///< Pointer used to index linked list ~array
	int index;				   ///< Position pointed to by current (~array index)
	int length;				   ///< Length of the linked list
	void (*dtor)( T ** obj );  ///< Function pointer to user specified destructor

public:
	// Constructors, Destructor
	inline DLinkedList(): length(0), head(NULL), tail(NULL), current(NULL),
		index(0), dtor(NULL) {};

	// This constructor is used to specify a custom destructor for class T data
	inline DLinkedList( void (*dtorFP)(T ** obj) ): length(0), head(NULL), tail(NULL), current(NULL),
		index(0), dtor(dtorFP) {};

	inline ~DLinkedList()
	{
		clear();
	}; 

	// Methods
	/**********************************************************************//**
	 * \brief push_back - Push object on back of DLL.
	 *
	 * Adds a node storing obj to the tail.  The linked list now has ownership
	 * of the data until it is popped off.
	 *************************************************************************/
	inline void push_back(T* obj)
	{
		Node<T>* new_node = new Node<T>(NULL,NULL,obj);
		Node<T>* old_tail = get_tail_node();

		if(old_tail == NULL)
		{
			set_tail(new_node);
			set_head(new_node);
			current = new_node;
			index = 0;
		}
		else 
		{
			old_tail->set_next(new_node);
			new_node->set_prev(old_tail);

			set_tail(new_node);
		}
		length++;
	};

	/**********************************************************************//**
	 * \brief push_front - Push object on front of DLL.
	 *
	 * Adds a node storing obj to the head.  The linked list now has ownership
	 * of the data until it is popped off.
	 *************************************************************************/
	inline void push_front(T* obj)
	{
		Node<T>* new_node = new Node<T>(NULL,NULL,obj);
		Node<T>* old_head = get_head_node();

		if(old_head == NULL)
		{
			set_tail(new_node);
			set_head(new_node);
			current = new_node;
			index = 0;
		}
		else
		{
			// Update index properly
			index++;

			// Update nodes
			old_head->set_prev(new_node);
			new_node->set_next(old_head);

			set_head(new_node);
		}
		length++;
	};

	/**********************************************************************//**
	 * \brief pop_back - Pop node off back of DLL and return contents.
	 *
	 * Removes the tail node and returns the data stored to the caller.  The
	 * caller now has ownership of the data.
	 *************************************************************************/
	inline T* pop_back()
	{
		Node<T>* old_tail = get_tail_node();
		Node<T>* new_tail = NULL;

		if(old_tail == NULL)
			return NULL;

		// Check if the tail was the only element in the list
		if(length == 1)
		{	
			set_head(NULL);
			set_tail(NULL);
			current = NULL;
			index = 0;
		}
		else
		{
			// Move current pointer and index as necessary
			if( index == (length-1) )
				dec_index();

			new_tail = old_tail->get_prev();
			new_tail->set_next(NULL);
			set_tail(new_tail);
		}
		
		T* pop_data = old_tail->get_data();
		delete old_tail;
		length--;

		return pop_data;
	};	

	/**********************************************************************//**
	 * \brief pop_front - Pop node off front of DLL and return contents.
	 *
	 * Removes the head node and returns the data stored to the caller.  The
	 * caller now has ownership of the data.
	 *************************************************************************/
	inline T* pop_front()
	{
		Node<T>* old_head = get_head_node();
		Node<T>* new_head = NULL;

		if(old_head == NULL)
			return NULL;
				
		// check if the tail was the only element in the list
		if(length == 1)
		{	
			set_head(NULL);
			set_tail(NULL);
			current = NULL;
			index = 0;
		}
		else
		{
			// Move current pointer and index as necessary
			if( index == (length-1) )
				index--;
			else
				current = current->get_next();

			// Remove old head and setup new one
			new_head = old_head->get_next();
			new_head->set_prev(NULL);
			set_head(new_head);
		}
		
		T* pop_data = old_head->get_data();
		delete old_head;
		length--;

		return pop_data;
	};

	/**********************************************************************//**
	 * \brief insert_at - Insert node at index of DLL.
	 *
	 * Inserts the object at specified index.  The DLL now has ownership of
	 * the data.  It is possible to insert a node anywhere from index 0 to
	 * index == size() (which is the same as push_back()).
	 *
	 * Requirement: index >= 0, index <= size()
	 *
	 * Returns true upon success, false if index out of bounds.
	 *************************************************************************/
	inline bool insert_at(T* obj, int index)
	{
		Node<T>* new_node = NULL;
		Node<T>* targ_node = NULL;
		
		// Check simple case
		if( index == 0 )
		{
			this->push_front(obj);
			return(true);
		}
		else if( index == length )
		{
			this->push_back(obj);
			return(true);
		}
		
		// Check index is in bounds
		if(index < 0 || index > length)
			return(false);
		
		/* Insert node into the middle */
		new_node = new Node<T>(NULL,NULL,obj);
		
		// Move current pointer and index as necessary
		if( this->index == index )
			current = new_node;
		else if( this->index > index )
			current = current->get_prev();
		
		// Move to target node
		targ_node = get_head_node();
		while( index > 0 )
		{
			targ_node = targ_node->get_next();
			index--;
		}

		// Target node becomes new node's next, target's prev is new node's prev
		new_node->set_prev(targ_node->get_prev());
		new_node->set_next(targ_node);

		// Update prev and next nodes
		new_node->get_prev()->set_next(new_node);
		targ_node->set_prev(new_node);

		length++;

		return(true);
	};

	/**********************************************************************//**
	 * \brief pop_at - Pop node at index of DLL and return contents.
	 *
	 * Removes the node at specified index and returns the data stored to the
	 * caller.  The caller now has ownership of the data.
	 *
	 * Note: When the node being popped is at an index before the current 
	 * index, the current index stays the same and the current node moves to
	 * its next so that it matches the index.
	 *************************************************************************/
	inline T* pop_at(int index)
	{
		Node<T>* old_node = NULL;
		
		// Check simple cases
		if( index == 0 )
			return this->pop_front();
		else if( index == length - 1 )
			return this->pop_back();

		// Check index is in bounds
		if(index < 0 || index >= length)
			return NULL;
		
		/* Remove node from the middle */
		
		// Move current pointer and index as necessary
		if( this->index >= index )
			current = current->get_next();
		
		// Remove old node
		old_node = get_head_node();
		while( index > 0 )
		{
			old_node = old_node->get_next();
			index--;
		}

		(old_node->get_prev())->set_next( old_node->get_next() );
		(old_node->get_next())->set_prev( old_node->get_prev() );
				
		T* pop_data = old_node->get_data();
		delete old_node;
		length--;

		return pop_data;
	};

	/**********************************************************************//**
	 * \brief pop_current - Pop node at current index of DLL, return contents.
	 *
	 * Removes the node at the current index and returns the data stored to the
	 * caller.  The caller now has ownership of the data.
	 *
	 * The current pointer will move to the deleted nodes next node if
	 * possible, unless the current node is the tail, in which case the current
	 * node remains the tail.
	 *************************************************************************/
	inline T* pop_current()
	{
		Node<T>* old_node = NULL;
		
		// Check simple cases
		if(  this->index == 0 )
			return this->pop_front();
		else if(  this->index == length - 1 )
			return this->pop_back();

		/* Remove node from the middle */
		
		// Get old node
		old_node = current;

		// Move current pointer to next if possible
		current = current->get_next();

		// Remove old node
		(old_node->get_prev())->set_next( old_node->get_next() );
		(old_node->get_next())->set_prev( old_node->get_prev() );
				
		T* pop_data = old_node->get_data();
		delete old_node;
		length--;

		return pop_data;
	};

	/**********************************************************************//**
	 * \brief size - Number of nodes in the DLL.
	 *
	 * Number of nodes (data) stored in the list.
	 *************************************************************************/
	inline int size()
	{	
		return length;
	};

	/**********************************************************************//**
	 * \brief clear - Deletes all nodes and their contents.
	 *
	 * Deletes all nodes and all data in the list.  Because the list assumes
	 * ownership of all data it deletes, this will delete the data stored
	 * in each node.
	 *************************************************************************/
	inline void clear()
	{
		while(length)
		{
			delete_front();
		}
	};
	
	/**********************************************************************//**
	 * \brief delete_front - Deletes node from front of DLL and its contents.
	 *
	 * Deletes the head node and its data.
	 *************************************************************************/
	inline void delete_front()
	{
		T* obj = pop_front();
		if( dtor == NULL )
		{
			if(obj != NULL)
				delete obj;				// Use default dtor
		}
		else
		{
			if(obj != NULL)
				(*dtor)( &obj );		// User specified dtor
		}
	};

	/**********************************************************************//**
	 * \brief set_dtor - Sets the destructor function pointer.
	 *
	 * Set the destructor used to destroy data of Class T stored in the list.
	 *************************************************************************/
	inline void set_dtor( void (*dtorFP)( T ** obj ) )
	{
		dtor = dtorFP;
	}

	/**********************************************************************//**
	 * \brief get_head_node - Returns pointer to head node.
	 *
	 * Returns a pointer to the head node.
	 *************************************************************************/
	inline Node<T>* get_head_node()
	{
		return head;
	};

	/**********************************************************************//**
	 * \brief get_tail_node - Returns pointer to tail node.
	 *
	 * Returns a pointer to the tail node.
	 *************************************************************************/
	inline Node<T>* get_tail_node()
	{
		return tail;
	};

	/**********************************************************************//**
	 * \brief set_tail - Set node to be tail node.
	 *
	 * Sets the pointer to the tail node.
	 *************************************************************************/
	inline void set_tail(Node<T>* new_tail)
	{
		tail = new_tail;
	};

	/**********************************************************************//**
	 * \brief set_head - Set node to be head node.
	 *
	 * Sets the pointer to the head node.
	 *************************************************************************/
	inline void set_head(Node<T>* new_head)
	{
		head = new_head;
	};

	/**********************************************************************//**
	 * \brief get_index - Get the current index into the DLL.
	 *
	 * Returns the index of where the current node pointer is pointing in the
	 * list.  This is similar to an index into an array.
	 *************************************************************************/
	int get_index()
	{
		return index;
	}

	/**********************************************************************//**
	 * \brief set_index - Set the internal index in the DLL.
	 *
	 * Sets the index and the current node pointer to the specified index.
	 * This is similar to an index into an array.
	 *
	 * Returns -1 if index is too low (out of bounds).
	 * Returns 1 if index is too high (out of bounds).
	 * Returns 0 upon success.
	 * \return -1 index < 0, 1 index > size()-1, 0 upon success.
	 *************************************************************************/
	int set_index(int index)
	{
		int diff = index - this->index;
		//int i = 0;

		if(index < 0)
		{		
			return -1;
		}
		else if( index >= length)
		{
			return 1;
		}
		else if( diff > 0 )
		{
			while( diff > 0 )
			{
				current = current->get_next();
				diff--;
			}
		}
		else
		{
			while( diff < 0 )
			{
				current = current->get_prev();
				diff++;
			}
		}

		this->index = index;
		return 0;
	}

	/**********************************************************************//**
	 * \brief set_index_head - Set internal index to head node.
	 *
	 * Points the array index and current pointer to the head.
	 *************************************************************************/
	void set_index_head()
	{
		index = 0;
		current = this->get_head_node();
	}

	/**********************************************************************//**
	 * \brief set_index_tail - Set internal index to tail node.
	 *
	 * Points the array index and current pointer to the tail.
	 *************************************************************************/
	void set_index_tail()
	{
		if( tail != NULL )
		{
			index = length-1;
			current = this->get_tail_node();
		}
	}

	/**********************************************************************//**
	 * \brief inc_index - Increment internal index.
	 *
	 * Increments the index and current pointer up one (to the next node).
	 * Returns 0 upon success, -1 if index is already at the tail.
	 *************************************************************************/
	int inc_index()
	{
		if( index == length - 1 )
		{
			// Already at tail of list
			return -1;
		}
		
		// Increment index
		current = current->get_next();
		index++;

		return 0;
	}

	/**********************************************************************//**
	 * \brief dec_index - Decrement internal index.
	 *
	 * Decrements the index and current pointer down one (to the prev node).
	 * Returns 0 upon success, -1 if index is already at the head.
	 *************************************************************************/
	int dec_index()
	{
		if( index == 0 )
		{
			// Already at head of list
			return -1;
		}
		
		// Decrement index
		current = current->get_prev();
		index--;

		return 0;
	}

	/**********************************************************************//**
	 * \brief get - Return contents of node at specified index.
	 *
	 * Returns the data stored at the index specified.  This is a slow
	 * operation because it requires traversing a link for each node
	 * from the head to the specified node.  For looping through the list
	 * try using get_and_inc() or get_cur() (if you have set the index and
	 * thus the current pointer correctly).
	 *************************************************************************/
	inline T* get(int index)
	{
		if(index < 0)
		{		
			return NULL;
		}
		else if( index >= length)
		{
			return NULL;
		}
		else{
			return getIndexTailRec(get_head_node(), index);
		}
	};

	/**********************************************************************//**
	 * \brief getIndexTailRec - Recursive function to get contents at index.
	 *
	 * Recursive function for returning data in a node at the specified index.
	 *************************************************************************/
	inline T* getIndexTailRec(Node<T>* curNode, int index)
	{

		if(index == 0)
		{
			return curNode->get_data();
		}
		else
		{
			return getIndexTailRec(curNode->get_next(), --index);
		}
	};

	/**********************************************************************//**
	 * \brief get_head - Get contents of head node.
	 *
	 * Returns the data at the head of the list without popping it.
	 * The list maintains ownership of the data.
	 *************************************************************************/
	inline T* get_head()
	{
		if( head != NULL )
			return head->get_data();
		else
			return NULL;
	}

	/**********************************************************************//**
	 * \brief get_tail - Get contents of tail node.
	 *
	 * Returns the data at the tail of the list without popping it.
	 * The list maintains ownership of the data.
	 *************************************************************************/
	inline T* get_tail()
	{
		if( tail != NULL )
			return tail->get_data();
		else
			return NULL;
	}

	/**********************************************************************//**
	 * \brief get_cur - Get contents of node at current internal index.
	 *
	 * Returns the data at the node in the list specified by the current
	 * pointer without popping it. The list maintains ownership of the data.
	 * This is faster than get(int index) if the index variable is already
	 * set to the desired index or is close to it (and can be set using
	 * set_index(int index)).
	 *************************************************************************/
	inline T* get_cur()
	{
		if( current != NULL )
			return current->get_data();
		else
			return NULL;
	}

	/**********************************************************************//**
	 * \brief get_and_inc - Get contents at current index and incremenet index.
	 *
	 * Returns the data at the node in the list specified by the current
	 * pointer without popping it. The list maintains ownership of the data.
	 * Then increments the index and current pointer forward one.  This is
	 * useful for looping through the list as it is faster (~ an array).
	 *************************************************************************/
	inline T* get_and_inc()
	{
		if( current != NULL )
		{
			T* obj = current->get_data();
			inc_index();
			return obj;
		}
		else
			return NULL;
	}

	/**********************************************************************//**
	 * \brief get_and_dec - Get contents at current index and decremenet index.
	 *
	 * Returns the data at the node in the list specified by the current
	 * pointer without popping it. The list maintains ownership of the data.
	 * Then decrements the index and current pointer back one.  This is useful
	 * for looping through the list as it is faster (~ an array).
	 *************************************************************************/
	inline T* get_and_dec()
	{
		if( current != NULL )
		{
			T* obj = current->get_data();
			dec_index();
			return obj;
		}
		else
			return NULL;
	}

	/**********************************************************************//**
	 * \brief swap_cur_w_prev - Swap current node with previous one.
	 *
	 * Swap the current indexed node with the one before it.
	 *************************************************************************/
	int swap_cur_w_prev()
	{
		T * temp = NULL;
		if( current != NULL && index > 0)
		{
			temp = current->get_prev()->get_data();
			current->get_prev()->set_data( current->get_data() );
			current->set_data( temp );
			return(0);
		}
		else
			return(-1);	// Error
	}

	/**********************************************************************//**
	 * \brief swap_cur_w_next - Swap current node with next one.
	 *
	 * Swap the current indexed node with the one after it.
	 *************************************************************************/
	int swap_cur_w_next()
	{
		T * temp = NULL;
		if( current != NULL && index < length-1 && length > 1)
		{
			temp = current->get_next()->get_data();
			current->get_next()->set_data( current->get_data() );
			current->set_data( temp );
			return(0);
		}
		else
			return(-1);	// Error
	}
};

#endif
