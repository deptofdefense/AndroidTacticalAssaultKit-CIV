#ifndef PRI_EXPORT_H
#define PRI_EXPORT_H

#if defined _WIN32 || defined __CYGWIN__
#if defined(PAGAN_EXPORTS)
#	define PAGAN_API_EXPORT __declspec(dllexport)
#else
#	define PAGAN_API_EXPORT
#endif //PAGAN_EXPORTS
#else
#if __GNUC__ >= 4
#if defined(PAGAN_EXPORTS)
#	define PAGAN_API_EXPORT __attribute__ ((visibility("default")))
#else
#	define PAGAN_API_EXPORT __attribute__ ((visibility("default")))
#endif //PAGAN_EXPORTS
#else
#define PAGAN_API_EXPORT
#endif // GNUC
#endif // WIN32

#endif
