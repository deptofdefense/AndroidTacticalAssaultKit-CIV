#ifndef _NODE_H
#define _NODE_H

/*************************** Version: trunk ***************************/

/// Node in a Double Linked List
/*************************************************************************//**
 * Node in a Double Linked List, used by DLinkedList.
 *****************************************************************************/
template <class T>
class Node
{
private:
	Node* next;		///< Link to next Node.
	Node* prev;		///< Link to previous Node.
	T* my_data;		///< Internally stored data.  Node doesn't assume ownership.
	
public:
	inline Node(void): next(NULL), prev(NULL), my_data(NULL) {};

	inline Node(Node* n, Node* p, T* new_data):
		next(n), prev(p), my_data(new_data) {};

	~Node(void) 
	{ 
		next = NULL;
		prev = NULL;
		my_data = NULL;
	};
	
	inline Node* get_next() { return next; };

	inline Node* get_prev() { return prev; };

	inline T* get_data() { return my_data; };

	inline void set_next(Node* new_next) { next = new_next; };

	inline void set_prev(Node* new_prev) { prev = new_prev; };

	inline void set_data(T* new_data) { my_data = new_data; };
};

#endif // _NODE_H