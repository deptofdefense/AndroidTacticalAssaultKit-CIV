#include <iostream>
#include "Extension.h"

using namespace std;

#ifndef NITF_ICHIPB_H
#define NITF_ICHIPB_H

class ICHIPB : public Extension{
private:
	void readTags();
	void initializeTags();
	int XFRM_FLAG_LENGTH;
	int SCALE_FACTOR_LENGTH;
	int ANAMRPH_CORR_LENGTH;
	int SCANBLK_NUM_LENGTH;
	int OP_ROW_11_LENGTH;
	int OP_COL_11_LENGTH;
	int OP_ROW_12_LENGTH;
	int OP_COL_12_LENGTH;
	int OP_ROW_21_LENGTH;
	int OP_COL_21_LENGTH;
	int OP_ROW_22_LENGTH;
	int OP_COL_22_LENGTH;
	int FI_ROW_11_LENGTH;
	int FI_COL_11_LENGTH;
	int FI_ROW_12_LENGTH;
	int FI_COL_12_LENGTH;
	int FI_ROW_21_LENGTH;
	int FI_COL_21_LENGTH;
	int FI_ROW_22_LENGTH;
	int FI_COL_22_LENGTH;
	int FI_ROW_LENGTH;
	int FI_COL_LENGTH;
public:
	ICHIPB(string treTag, int treLength, string treData);
	ICHIPB(const ICHIPB& extension);
	ICHIPB(const ICHIPB  *const extension);
    virtual ~ICHIPB();
	virtual Extension* copy();
	void printTags();

	int xfrm_flag;
	double scale_factor;
	int anamrph_corr;
	int scanblk_num;
	double op_row_11;
	double op_col_11;
	double op_row_12;
	double op_col_12;
	double op_row_21;
	double op_col_21;
	double op_row_22;
	double op_col_22;
	double fi_row_11;
	double fi_col_11;
	double fi_row_12;
	double fi_col_12;
	double fi_row_21;
	double fi_col_21;
	double fi_row_22;
	double fi_col_22;
	int fi_row;
	int fi_col;
};


#endif