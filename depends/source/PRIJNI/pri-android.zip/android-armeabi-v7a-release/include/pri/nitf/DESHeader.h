#include<iostream>

#include "FileHeader.h"
#include "DataReader.h"

using namespace std;

#ifndef NITF_DESHEADER_H
#define NITF_DESHEADER_H

class DESHeader{
private:
	DataReader *source;

	void initializeLengths();
	void jumpToCurrentSegment(FileHeader &fheader, int dheaderNum);
	void readStringTag(int length, string& var);
	void readIntTag(int length, int& var);
	void readCharTag(char& var);
	void readBoolTag(bool& var);
	void readLongLongTag(int length, long long& var);

	int DE_LENGTH;
	int DESID_LENGTH;
	int DESVER_LENGTH;
	int DESCLAS_LENGTH;
	int DESCLSY_LENGTH;
	int DESCODE_LENGTH;
	int DESCTLH_LENGTH;
	int DESREL_LENGTH;
	int DESDCTP_LENGTH;
	int DESDCDT_LENGTH;
	int DESDCXM_LENGTH;
	int DESDG_LENGTH;
	int DESDGDT_LENGTH;
	int DESCLTX_LENGTH;
	int DESCATP_LENGTH;
	int DESCAUT_LENGTH;
	int DESCRSN_LENGTH;
	int DESSRDT_LENGTH;
	int DESCTLN_LENGTH;
	int DESOFLW_LENGTH;
	int DESITEM_LENGTH;
	int DESSHL_LENGTH;
	int DESSHF_LENGTH;
	int DESDATA_LENGTH;

public:
	DESHeader();
	DESHeader(const DESHeader &header);
	int getDESLength();
	void setDESLength(int length);
	~DESHeader();
	void read(string sourceFile, FileHeader& fheader, int dheaderNum);
	void write(ostream *dest);
	void printTags();

	string de;
	string desid;
	int desver;
	char desclas;
	string desclsy;
	string descode;
	string desctlh;
	string desrel;
	string desdctp;
	string desdcdt;
	string desdcxm;
	char desdg;
	string desdgdt;
	string descltx;
	char descatp;
	string descaut;
	char descrsn;
	string dessrdt;
	string desctln;
	string desoflw;
	int desitem;
	int desshl;
	string desshf;
	char* desdata;

};

#endif