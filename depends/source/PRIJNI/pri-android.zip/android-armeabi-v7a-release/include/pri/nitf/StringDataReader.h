#ifndef NITF_STRINGDATAREADER_H
#define NITF_STRINGDATAREADER_H

#include <iostream>
#include <fstream>
#include <sstream>

#include "DataReader.h"

using namespace std;

class StringDataReader : public DataReader{
private:
	stringstream source;

public:
	StringDataReader(string);
	virtual ~StringDataReader() {}

	void read(unsigned char*, long long);
	void seek(long long, STARTING_POINT);
	long long tell();
	bool eof();
	long long count();
};

#endif