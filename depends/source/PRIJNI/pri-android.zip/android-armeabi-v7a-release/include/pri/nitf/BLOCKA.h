#ifndef NITF_BLOCKA_H
#define NITF_BLOCKA_H

#include <string>
#include "Extension.h"

#include <iostream>
#include <limits>
#include "coord/GeoQuad.h"

// This class is used to write out the BLOCKA extension
// to a NITF image. 
// (Currently only writing is supported, not reading)
class BLOCKA : public Extension{


public:

	// Copy constructors
	BLOCKA(const BLOCKA &extension);
	BLOCKA(const BLOCKA *const extension);
	
	// nRows - number of rows in image
	// corners - NITF corners
	BLOCKA(int nRows, iai::GeoQuad corners);

	virtual ~BLOCKA();
	virtual Extension* copy();

	void printTags();
	void writeTags();

	// After modifying any of these fields, call
	// 'writeTags()' to update the data string
	int block_instance;
	int n_gray;
	int l_lines;
	int layover_angle;
	int shadow_angle;
	string reserved1;
	string reserved2;

	// 4 corners as a string (set by constructor)
	string frlc_loc;
	string lrlc_loc;
	string lrfc_loc;
	string frfc_loc;



private:
	//TODO This method belongs in the NITF class
	// (it also appears in RPC00B
	bool writeDecimal(std::ostream& os, int length, 
						  bool showPosSign, int precision,
						  double dec,
						  double min, 
						  double max);

	void initializeTags();

	int BLOCK_INSTANCE_LENGTH;
	int N_GRAY_LENGTH;
	int L_LINES_LENGTH;
	int LAYOVER_ANGLE_LENGTH;
	int SHADOW_ANGLE_LENGTH;
	int RESERVED1_LENGTH;
	int FRLC_LOC_LENGTH;
	int LRLC_LOC_LENGTH;
	int LRFC_LOC_LENGTH;
	int FRFC_LOC_LENGTH;
	int RESERVED2_LENGTH;

// Used as a value for layover_angle or shadow_angle
// to indicate that the angle is not present in the tag
	static int EMPTY_ANGLE;
};

#endif