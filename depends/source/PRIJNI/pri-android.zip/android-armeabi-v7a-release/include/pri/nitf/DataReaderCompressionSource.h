// ----------------------------------------------------------------------------
// DataReaderCompressionSource
// CompressionSource that uses the DataReader class to interface
// with an outside source.
// It is assumed that the user of this object handles the creation/deletion
// of the DataReader object (If the DataReader object is deleted outside,
// then this object will no longer be valid either).
// ----------------------------------------------------------------------------

#ifdef J2K_SUPPORT
#ifndef DATAREADERCOMPRESSIONSOURCE_H
#define DATAREADERCOMPRESSIONSOURCE_H

#include <string>
#include <iostream>
#include <fstream>


#include "DataReader.h"
#include "CompressionSource.h"

using namespace std;

class DataReaderCompressionSource : public CompressionSource {

private:
	DataReader * &reader;
	kdu_long startPos;
	kdu_long endPos;
	kdu_long fileSize;

	void init();

public:


	// ----------------------------------------------------------------------------
	// DataReaderCompressionSource
	// Creates a kdu compressed source a DataReader 
	// (see kdu_compressed.h for more details)
	//
	// reader_in	DataReader used to read the data
	// startPos_in  The starting position of the J2K image inside the source
	// endPos_in	The ending position (if 0 is given, it will default to the 
	//				end of the source
	// ----------------------------------------------------------------------------
	DataReaderCompressionSource(DataReader * &reader_in, kdu_long startPos_in, kdu_long endPos_in):
	   reader(reader_in),
	   startPos(startPos_in),
	   endPos(endPos_in)
	   {
			init();
	   }

	~DataReaderCompressionSource();

	bool close();
	int get_capabilities();
	int read(kdu_byte *buf, int num_bytes);
	bool seek(kdu_long offset);
	kdu_long get_pos();

	bool seekWithStartingOffset(kdu_long newOffset);
	kdu_long getPositionFromStartingOffset();

};

#endif
#endif