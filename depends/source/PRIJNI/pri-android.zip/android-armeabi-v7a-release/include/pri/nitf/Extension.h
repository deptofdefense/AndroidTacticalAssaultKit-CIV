#include <iostream>

using namespace std;

#ifndef NITF_EXTENSION_H
#define NITF_EXTENSION_H

class Extension{
public:
	string tag;     // The 6-character name for the TRE
	string data;    // The TRE "payload," which is "length" characters long
	int length;     // The size of the "data" field. This will always be 5 characters long in the TRE
public:
    
    virtual ~Extension();
    
	virtual string getText();
	virtual string getTag();
	virtual int getLength();

	virtual Extension* copy() = 0;
};



#endif