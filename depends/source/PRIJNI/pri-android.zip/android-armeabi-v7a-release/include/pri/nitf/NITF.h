#ifndef NITF_NITF_H
#define NITF_NITF_H

#include <iostream>
#include <deque>
#include <fstream>
#include "ImageHeader.h"
#include "FileHeader.h"

#include "DESHeader.h"
#include "Extension.h"
#include "GeoQuad.h"

#include "DataReader.h"

enum IREP{
	MONO,
	RGB
};

class NITF{
private:
	static long long atoll(char *instr, int length);

	void clearBandFields(ImageHeader &header);
	bool initHeaderBandsRGB(ImageHeader &header);
	bool initHeaderBandsMONO(ImageHeader &header);

	bool checkImageNumber(int imageNumber);
	bool checkIfOpen();
	
	static string padInt(int input);

	string filename;

public:
	NITF();
	NITF(string);
	~NITF();

	enum GEO_FORMAT {
		//MGRS,		// Not yet supported
		//UTM/UPS,	// Not yet supported
		//UTM/UPS,	// Not yet supported
		GEOGRAPHIC_DMS,
		DECIMAL_DEGREES
	};

	void readFile(string);
	void writeFile(string);
	
	bool addImageSubHeader(unsigned char *data, FORMAT format, long long dataLength,
								int numrows, int numcols, IREP irep);
	bool addDataExtensionSegment(string desit, int desver, const char *data, int dataLength);
	bool addTreSegment(Extension* extension, size_t subheaderIndex);
	bool addIGEOLO(iai::GeoQuad& corners, GEO_FORMAT geoFormat, size_t subHeaderIndex);

	static void readStringTag(DataReader* source, int length, string& var);
	static void readIntTag(DataReader* source, int length, int& var);
	static void readCharTag(DataReader* source, char& var);
	static void readBoolTag(DataReader* source, bool& var);
	static void readLongLongTag(DataReader* source, int length, long long& var);
	static void readDoubleTag(DataReader* source, int length, double& var);

	static void writeStringTag(ostream *dest, int length, const string var);
	static void writeIntTag(ostream *dest, int length, const int var);
	static void writeSignedIntTag(ostream *dest, int length, const int var);
	static void writeBoolTag(ostream *dest, const bool var);
	static void writeCharTag(ostream *dest, const char var);
	static void writeLongLongTag(ostream *dest, int length, const long long var);
	static void writeDoubleTag(ostream *dest, int length, const double var);
    static void writeSignedDoubleTag(ostream *dest, int length, const double var);
    static void writeScientificTag(ostream *dest, int length, int exponentLength, const double var);
    static void writeSignedScientificTag(ostream *dest, int length, int exponentLength, const double var);

	// Getters
	iai::GeoQuad getCorners(int imageNumber);
	static string getTimeString();
	string getFilename();

	// Public member variables
	FileHeader fileHeader;
	deque<ImageHeader> imageSubHeaders;
	deque<DESHeader> desSubHeaders;
	
};



#endif