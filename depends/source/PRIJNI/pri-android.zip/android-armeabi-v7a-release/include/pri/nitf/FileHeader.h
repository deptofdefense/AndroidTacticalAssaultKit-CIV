#include <iostream>
#include <fstream>

#include "DataReader.h"

using namespace std;

#ifndef NITF_FILEHEADER_H
#define NITF_FILEHEADER_H

enum NITF_TYPE{
	NITF0200,
	NITF0210,
};

class FileHeader{
private:

	void switchTo20();

	void readStringTag(int length, string& var);
	void readIntTag(int length, int& var);
	void readCharTag(char& var);
	void readBoolTag(bool& var);
	void readLongLongTag(int length, long long& var);

	void initializeLengths();

	DataReader *source;

	NITF_TYPE fileType;

	int FHDR_LENGTH;
	int CLEVEL_LENGTH;
	int STYPE_LENGTH;
	int OSTAID_LENGTH;
	int FDT_LENGTH;
	int FTITLE_LENGTH;
	int FCLAS_LENGTH;
	int FSCLSY_LENGTH;
	int FSCODE_LENGTH;
	int FSCTLH_LENGTH;
	int FSREL_LENGTH;
	int FSDCTP_LENGTH;
	int FSDCDT_LENGTH;
	int FSDCXM_LENGTH;
	int FSDG_LENGTH;
	int FSDGDT_LENGTH;
	int FSCLTX_LENGTH;
	int FSCATP_LENGTH;
	int FSCAUT_LENGTH;
	int FSCRSN_LENGTH;
	int FSSRDT_LENGTH;
	int FSCTLN_LENGTH;
	int FSDWNG_LENGTH;
	int FSDEVT_LENGTH;
	int FSCOP_LENGTH;
	int FSCPYS_LENGTH;
	int ENCRYP_LENGTH;
	int FBKGC_LENGTH;
	int ONAME_LENGTH;
	int OPHONE_LENGTH;
	int FL_LENGTH;
	int HL_LENGTH;
	int NUMI_LENGTH;
	int LISH_LENGTH;
	int LI_LENGTH;
	int NUMS_LENGTH;
	int LSSH_LENGTH;
	int LS_LENGTH;
	int NUML_LENGTH;
	int LLSH_LENGTH;
	int LL_LENGTH;
	int NUMX_LENGTH;
	int NUMT_LENGTH;
	int LTSH_LENGTH;
	int LT_LENGTH;
	int NUMDES_LENGTH;
	int LDSH_LENGTH;
	int LD_LENGTH;
	int NUMRES_LENGTH;
	int LRESH_LENGTH;
	int LRE_LENGTH;
	int UDHDL_LENGTH;
	int UDHOFL_LENGTH;
	int UDHD_LENGTH;
	int XHDL_LENGTH;
	int XHDLOFL_LENGTH;
	int XHD_LENGTH;
public:
	FileHeader();
	FileHeader(const FileHeader &header);
	~FileHeader();

	void read(string sourceFile);
	void write(ostream *destFile);
	void printTags();
	
	string fhdr;
	int clevel;
	string stype;
	string ostaid;
	string fdt;
	string ftitle;
	char fclas;
	string fsclsy;
	string fscode;
	string fsctlh;
	string fsrel;
	string fsdctp;
	string fsdcdt;
	string fsdcxm;
	char fsdg;
	string fsdgdt;
	string fscltx;
	char fscatp;
	string fscaut;
	char fscrsn;
	string fssrdt;
	string fsctln;
	string fsdwng;
	string fsdevt;
	int fscop;
	int fscpys;
	bool encryp;
	char fbkgc[3];
	string oname;
	string ophone;
	long long fl;
	int hl;

	// Image Segment info.
	int numi;
	int* lish;
	long long* li;

	// Graphic Segment info.
	int nums;
	int* lssh;
	int* ls;

	// Label Segment info (NITF 2.0)
	int numl;
	int* llsh;
	int* ll;

	// Unused
	int numx;

	// Text Segment info.
	int numt;
	int* ltsh;
	int* lt;

	// Data Extension segment info.
	int numdes;
	int* ldsh;
	int* ld;

	// Reserved Extension segment info.
	int numres;
	int* lresh;
	int* lre;

	// User Defined Header info.
	int udhdl;
	int udhofl;
	string udhd;

	// Extended Header data info.
	int xhdl;
	int xhdlofl;
	string xhd;

};

#endif