#ifndef NITF_LARGEFILEREADER_H
#define NITF_LARGEFILEREADER_H

#include <iostream>

using namespace std;

enum STARTING_POINT{
	BEGINNING, CURRENT, END,
};

class DataReader{
public:
	
	virtual ~DataReader() {}
	virtual void read(unsigned char*, long long) = 0;
	virtual void seek(long long, STARTING_POINT) = 0;
	virtual long long tell() = 0;
	virtual bool eof() = 0;
	virtual long long count() = 0; // get num bytes read 

	static DataReader* getDataReaderForFile(string);
};



#endif