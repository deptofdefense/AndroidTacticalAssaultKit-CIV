#ifndef NITF_SENSRB_H
#define NITF_SENSRB_H

#include <string>
#include <vector>

#include "Extension.h"

class SENSRB : public Extension
{
public:
    
    SENSRB();
    SENSRB(const std::string& data);
    virtual ~SENSRB();
    
    virtual Extension* copy();
    
    struct GeneralDataModule {
		bool isValid;
		std::string sensor;
		std::string sensorUri;
		std::string platform;
		std::string platformUri;
		std::string operationDomain;
		int contentLevel;
		std::string geodeticSystem;
		char geodeticType;
		std::string elevationDatum;
		std::string lengthUnit;
		std::string angularUnit;
		std::string startDate;
		double startTime;
		std::string endDate;
		double endTime;
		int generationCount;
		std::string generationDate;
		std::string generationTime;
        GeneralDataModule() { isValid = false; }
	};
    
	struct SensorArrayDataModule {
		bool isValid;
		std::string detection;
		int rowDetectors;
		int columnDetectors;
		double rowMetric;
		double columnMetric;
		double focalLength;
		double rowFov;
		double columnFov;
		bool calibrated;
        SensorArrayDataModule() { isValid = false; }
	};
    
	struct SensorCalibrationDataModule {
		bool isValid;
		std::string calibrationUnit;
		double principalPointOffsetX;
		double principalPointOffsetY;
		double radialDistort1;
		double radialDistort2;
		double radialDistort3;
		double radialDistortLimit;
		double decentDistort1;
		double decentDistort2;
		double affinityDistort1;
		double affinityDistort2;
		std::string calibrationDate;
        SensorCalibrationDataModule() { isValid = false; }
	};
    
	struct ImageFormationDataModule {
		bool isValid;
		std::string method;
		std::string mode;
		int rowCount;
		int columnCount;
		int rowSet;
		int columnSet;
		double rowRate;
		double columnRate;
		int firstPixelRow;
		int firstPixelColumn;
		std::vector<double> transformParams;
        ImageFormationDataModule() { isValid = false; }
	};
    
	struct ReferenceTimeOrPixelModule {
		double referenceTime;
		int referenceRow;
		int referenceColumn;
	};
    
	struct SensorPositionDataModule {
		double latitudeOrX;
		double longitudeOrY;
		double altitudeOrZ;
		double sensorXOffset;
		double sensorYOffset;
		double sensorZOffset;
	};
    
	struct EulerAnglesModule {
		bool isValid;
		int sensorAngleModel;
		double sensorAngle1;
		double sensorAngle2;
		double sensorAngle3;
		bool platformRelative;
		double platformHeading;
		double platformPitch;
		double platformRoll;
        EulerAnglesModule() { isValid = false; }
	};
    
	struct UnitVectorsModule {
		bool isValid;
		double icxNorthOrX;
		double icxEastOrY;
		double icxDownOrZ;
		double icyNorthOrX;
		double icyEastOrY;
		double icyDownOrZ;
		double iczNorthOrX;
		double iczEastOrY;
		double iczDownOrZ;
        UnitVectorsModule() { isValid = false; }
	};
    
	struct QuaternionsModule {
		bool isValid;
		double attitudeQ1;
		double attitudeQ2;
		double attitudeQ3;
		double attitudeQ4;
        QuaternionsModule() { isValid = false; }
	};
    
	struct SensorVelocityModule {
		bool isValid;
		double velocityNorthOrX;
		double velocityEastOrY;
		double velocityDownOrZ;
        SensorVelocityModule() { isValid = false; }
	};
    
	struct PointDataset {
		struct Point {
			int pRow;
			int pColumn;
			double pLatitude;
			double pLongitude;
			double pElevation;
			double pRange;
		};
		std::string pointSetType;
		std::vector<Point> points;
	};
    
	struct TimeStampedDataset {
		struct TimeStampedValue {
			double time;
			double value;
		};
		std::string timeStampType;
		std::vector<TimeStampedValue> timeStampedValues;
	};
    
	struct PixelReferencedDataset {
		struct PixelReferencedValue {
			int row;
			int column;
			double value;
		};
		std::string pixelReferenceType;
		std::vector<PixelReferencedValue> pixelReferencedValues;
	};
    
	struct UncertaintyData {
		std::string uncertaintyFirstType;
		std::string uncertaintySecondType;
		double uncertaintyValue;
	};
    
	struct AdditionalParameter {
		std::string parameterName;
		std::vector<std::string> parameterValues;
	};
    
	GeneralDataModule generalDataModule;
	SensorArrayDataModule sensorArrayDataModule;
	SensorCalibrationDataModule sensorCalibrationDataModule;
	ImageFormationDataModule imageFormationDataModule;
	ReferenceTimeOrPixelModule referenceTimeOrPixelModule;
	SensorPositionDataModule sensorPositionDataModule;
	EulerAnglesModule eulerAnglesModule;
	UnitVectorsModule unitVectorsModule;
	QuaternionsModule quaternionsModule;
	SensorVelocityModule sensorVelocityModule;
	std::vector<PointDataset> pointDatasetsModule;
	std::vector<TimeStampedDataset> timeStampedDataModule;
	std::vector<PixelReferencedDataset> pixelReferencedDataModule;
	std::vector<UncertaintyData> uncertaintyDataModule;
	std::vector<AdditionalParameter> additionalParameterDataModule;
    
	/**
	 * Performs internal conversions necessary so that after calling this
	 * function:
	 * - all length units in the sensrb structure are in SI units
	 * - all angular units in the structure are in radians
	 * - the elevation datum used in the structure is HAE
	 * - the geodetic datum used in the structure is WGS84
	 * The function throws an exception if this process cannot be carried out.
	 **/
	void standardize();
    
    /**
     * Uses all of the current values of its internal fields to update the "data"
     * field so that it is consistent with the rest of the data.
     **/
    void updateDataField();
    
private:
    
    void parseData();
    
    inline std::string trim(const std::string& s) {
        static const std::string WHITESPACE(" \t\n");
        size_t startIndex = s.find_first_not_of(WHITESPACE);
        size_t endIndex = s.find_last_not_of(WHITESPACE);
        return (startIndex == std::string::npos) ? std::string() : s.substr(startIndex, endIndex + 1 - startIndex);
    }
    
    /**
	 * Returns the length of the SENSRB field with the given index, or -1 if the
	 * index is not valid.  Valid indices are those between 06a and 10c, not
	 * including 07a and 07e.
	 **/
	static int fieldLength(const std::string& fieldIndex);
    
};


#endif