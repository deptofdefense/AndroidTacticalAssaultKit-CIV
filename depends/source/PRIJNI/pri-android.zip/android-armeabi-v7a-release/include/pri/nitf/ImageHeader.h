#ifndef NITF_IMAGEHEADER_H
#define NITF_IMAGEHEADER_H

#ifdef J2K_SUPPORT
#include "J2KImage.h"
#endif

#include <iostream>
#include <fstream>
#include <limits>

#include "FileHeader.h"
#include "Extension.h"
#include "GeoQuad.h"
#include "NitfASDE.h"
#include "DataReader.h"

struct TRE{
	string tag;
	int length;
	string data;
};

enum FORMAT{
	PIXELS,
	JPEG,
	OPENCV // Same as pixels, except the color order is BGR, 
		   // and rows have a 4-byte alignment restriction
		   // NOTE: OPENCV format is not meant to be written to disk!
};

class ImageHeader{
private:

	bool findNext(const unsigned char *bytes, 
				int byteLength, int &nextPos, int &offset);
	bool parseJPEGHeaders();
	void readAndConvert16BitData(unsigned char *destBuf);
	void readAndConvert16BitData(DataReader *sourceStream, 
									unsigned char *destBuf,
									long long dataLength);
	bool IBB2RGB(unsigned char *ibbBlockBuf, unsigned char *rgbBlockBuf,
					int blockNumX, int blockNumY);
	bool IBP2RGB(unsigned char *ibpBlockBuf, unsigned char *rgbBlockBUf,
					int blockNumX, int blockNumY);
	bool readInterleavedByBlock(unsigned char *sourceBuf, unsigned char *destBuffer);
	bool readInterleavedByBlock(unsigned char *sourceBuf, unsigned char *destBuffer,
								int startBlockX, int startBlockY,
								int blockWidth, int blockHeight);
	bool readInterleavedByPixel(unsigned char *sourceBuf, unsigned char *destBuffer);
	bool readInterleavedByPixel(unsigned char *sourceBuf, unsigned char *destBuffer,
								int startBlockX, int startBlockY,
								int blockWidth, int blockHeight);
	void copyImageDataToBuffer(unsigned char *sourceBuf, unsigned char *destBuf);
	void compressAndStoreRGBImageFromDisk();
	void compressBufferInPlace(int imageWidth, int imageHeight, unsigned char *&buffer, long long *bufferLength);
	void copyJPEGBlock(unsigned char *destBuf, long long bufferSize, int bufferWidth, int startX, int startY, int blockNum);
	bool readAllJPEGBlocksRGB();
	
	void setWidthStep();
	bool imageDataToOpenCV();

	bool writeInterleavedByBlock(ostream *dest);

	Extension* createExtension(TRE& text);
	void parseTREs();

	double latDMSToDegrees(string value);
	double lonDMSToDegrees(string value);
	static string formatLat(double lat);
	static string formatLon(double lon);

	void copyString(string &input, string &output);
	void readStringTag(int length, string& var);
	void readIntTag(int length, int& var);
	void readCharTag(char& var);
	void readBoolTag(bool& var);
	void readLongLongTag(int length, long long& var);

	void initializeLengths();

	void deleteExtensions();

	string sourceFileString;
	DataReader *source;
	long long imageStart;
	long long imageLength;

	bool isChip;

	FORMAT outputFormat;

	int widthStep;
	int chipWidth;
	int chipHeight;

	long *SOI;
	long *EOI;
	
	Extension **extensions;
	int numExtensions;

	int IM_LENGTH;
	int IID1_LENGTH;
	int IDATIM_LENGTH;
	int TGTID_LENGTH;
	int IID2_LENGTH;
	int ISCLAS_LENGTH;
	int ISCLSY_LENGTH;
	int ISCODE_LENGTH;
	int ISCTLH_LENGTH;
	int ISREL_LENGTH;
	int ISDCTP_LENGTH;
	int ISDCDT_LENGTH;
	int ISDCXM_LENGTH;
	int ISDG_LENGTH;
	int ISDGDT_LENGTH;
	int ISCLTX_LENGTH;
	int ISCATP_LENGTH;
	int ISCAUT_LENGTH;
	int ISCRSN_LENGTH;
	int ISSRDT_LENGTH;
	int ISCTLN_LENGTH;
	int ENCRYP_LENGTH;
	int ISORCE_LENGTH;
	int NROWS_LENGTH;
	int NCOLS_LENGTH;
	int PVTYPE_LENGTH;
	int IREP_LENGTH;
	int ICAT_LENGTH;
	int ABPP_LENGTH;
	int PJUST_LENGTH;
	int ICORDS_LENGTH;
	int IGEOLO_LENGTH;
	int NICOM_LENGTH;
	int ICOM_LENGTH;
	int IC_LENGTH;
	int COMRAT_LENGTH;
	int NBANDS_LENGTH;
	int XBANDS_LENGTH;
	int IREPBAND_LENGTH;
	int ISUBCAT_LENGTH;
	int IFC_LENGTH;
	int IMFLT_LENGTH;
	int NLUTS_LENGTH;
	int NELUT_LENGTH;
	int LUTD_LENGTH;
	int ISYNC_LENGTH;
	int IMODE_LENGTH;
	int NBPR_LENGTH;
	int NBPC_LENGTH;
	int NPPBH_LENGTH;
	int NPPBV_LENGTH;
	int NBPP_LENGTH;
	int IDLVL_LENGTH;
	int IALVL_LENGTH;
	int ILOC_LENGTH;
	int IMAG_LENGTH;
	int UDIDL_LENGTH;
	int UDOFL_LENGTH;
	int UDID_LENGTH;
	int IXSHDL_LENGTH;
	int IXSOFL_LENGTH;
	int IXSHD_LENGTH;

	int TRE_TAG_LENGTH;
	int TRE_L_LENGTH;

	// Other possible fields within the extended header
	double minLat;
	double minLon;
	double maxLat;
	double maxLon;
	// Useful variables
	double ullat;
	double ullon;
	double urlat;
	double urlon;
	double lrlat;
	double lrlon;
	double lllat;
	double lllon;

	//J2K
#ifdef J2K_SUPPORT
	J2KImage * j2k;

// Optional J2K parameters
	J2KOptions j2kopt;
#endif

public:
	ImageHeader();
	ImageHeader(const ImageHeader &header);
	~ImageHeader();

	bool hasChippedData();
	void read(string sourceFile, FileHeader& fheader, int iheaderNum);
	bool readImage();
	bool readImageChip(int startX, int startY, int readWidth, int readHeight);

	void write(ostream *dest);
	
	Extension* getExtension(string tag);
	void addExtension(Extension* newExtension);

	bool parseIGEOLO(string igeolo);
	static string createIGEOLOString(iai::GeoQuad& corners);
	void setIGEOLO(iai::GeoQuad& corners);

	//<geographic>
	void angToDMS(double ang, 
					int& deg, 
					int& min,
					int& sec,
					bool& neg);
	std::string formatGeographicLat(double ang);
	std::string formatGeographicLon(double ang);
	std::string createGeographicIGEOLOString(iai::GeoQuad& corners);
	void setGeographicIGEOLO(iai::GeoQuad& corners);
	//</geographic>


	// Getters
	void getFourCorners(iai::GeoQuad& corners);	// Supposed to be "SET"FourCorners()????
	string getCorners();
	int getBPP();
	int getNumExtensions();
	int getIGEOLOLength()	{ return IGEOLO_LENGTH; }
	int getIXSOFLLength()	{ return IXSOFL_LENGTH; }

	void setImageFormat(FORMAT newFormat);

	static double string_to_double( const std::string& s );
	static int string_to_int( const std::string& s );

	void printTags();


#ifdef J2K_SUPPORT
	// Set optional parameters
	void setJ2KOptions(J2KOptions opt);
#endif

	unsigned char* imageData;
	long long imageDataLength;

	string im;
	string iid1;
	string idatim;
	string tgtid;
	string iid2;
	char isclas;
	string isclsy;
	string iscode;
	string isctlh;
	string isrel;
	string isdctp;
	string isdcdt;
	string isdcxm;
	char isdg;
	string isdgdt;
	string iscltx;
	char iscatp;
	string iscaut;
	string iscrsn;
	string issrdt;
	string isctln;
	bool encryp;
	string isorce;
	int nrows;
	int ncols;
	string pvtype;
	string irep;
	string icat;
	int abpp;
	char pjust;
	char icords;
	string igeolo;
	int nicom;
	string* icom;
	string ic;
	string comrat;
	int nbands;
	int xbands;
	string* irepband;
	string* isubcat;
	string* ifc;
	string* imflt;
	int* nluts;
	int* nelut;
	char** lutd;
	int isync;
	char imode;
	int nbpr;
	int nbpc;
	int nppbh;
	int nppbv;
	int nbpp;
	int idlvl;
	int ialvl;
	string iloc;
	// Imag field can store a double, or it can 
	// store a string representing a fraction.
	// Valid fractions are "/2", "/4", "/8", "/16",
	// "/32", "/64", and "/128". These represent
	// "one over x" where x is the number in the 
	// string, i.e. "/32" represents "1/32" times
	// magnification.
	string imag;
	int udidl;
	int udofl;
	string udid;
	int ixshdl;
	int ixsofl;
	string ixshd;
	NitfASDE * ASDE;
};



#endif