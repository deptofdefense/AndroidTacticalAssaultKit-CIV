#ifndef NITF_ANSIFILEREADER_H
#define NITF_ANSIFILEREADER_H

#include <iostream>
#include <fstream>

#include "DataReader.h"

using namespace std;

class ANSIFileReader : public DataReader{
private:
	ifstream source;

public:
	ANSIFileReader(string);
	virtual ~ANSIFileReader();

	void read(unsigned char*, long long);
	void seek(long long, STARTING_POINT);
	long long tell();
	bool eof();
	long long count();
};

#endif