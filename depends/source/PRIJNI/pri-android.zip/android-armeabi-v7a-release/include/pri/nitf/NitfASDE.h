#ifndef NITF_ASDE_H
#define NITF_ASDE_H

#include <stdlib.h>
#include <string>
#include <vector>
#include <map>
#include <limits>

using namespace std;

typedef std::map<std::string, std::string> HASH_S_S;

struct BlockAField{
public:
	string name;	// key
	int size;	// value

	BlockAField()  : name(""), size(0) {}
	BlockAField(string _name, int _size) {
		name = _name;
		size = _size;
	}
};
/**
 * Class for handling content of ASDE tagged records. 
 * <p>
 * In method,<br>
 * <code>this.asde.parseASDE();</code>
 * <p>
 * Before using get methods, use <code>isAvailable()</code> method to confirm
 * the availability of ASDE data.
 * 
 * @author S. Meshkat
 * @version 01/10/11
 */
class NitfASDE{
private:
	/*
	 * Class variables
	 */

	 bool showDebugMessages;

	// flag indicating whether ASDE records were found in the NITF subheader
	 bool availabilityFlag;

	 string sensorType;
	 string specificType;

	 //Date collectionDate;

	 string countryCode;

	 double elevationAngle;
	 double azimuthAngle;

	 double sensorLat;
	 double sensorLon;
	 double sensorAlt;

	 double sensorRoll;
	 double sensorPitch;
	 double sensorYaw;

	 double platformRoll;
	 double platformPitch;
	 double platformHdg;

	 double imageCenterLat;
	 double imageCenterLon;
	 string rlmap;
	 double squintAngle;
	 double grazeAngle;
	 int cloudCover;
	
	 double niirs;

	void computeAzimuthAndElevationAngle();
	void parseAIMIDA(string str);
	void parseAIMIDB(string str);
	void parseACFTA(string str);
	void parseACFTB(string str);
	void parseSENSRA(string str);
	void parseMENSRA(string str);
	void parseEXPLTA(string str);
	void parsePIAIMB(string str);
	void parsePIAIMC(string str);
	void parseBLOCKA(string str);
	std::string getCEL(string str, int start, int end);
	void parseExtensionString(string str, const vector<BlockAField>& fieldArray, 
		HASH_S_S& fieldHash);
	bool parseBlockACoordinateString(string str, double lat_lon[]);

public:
	 double ullat;
	 double ullon;
	 double urlat;
	 double urlon;
	 double lrlat;
	 double lrlon;
	 double lllat;
	 double lllon;

	NitfASDE();
	~NitfASDE() {};
	bool isAvailable();
	void parseASDE(string str);
	static double string_to_double( const std::string& s );
};

#endif