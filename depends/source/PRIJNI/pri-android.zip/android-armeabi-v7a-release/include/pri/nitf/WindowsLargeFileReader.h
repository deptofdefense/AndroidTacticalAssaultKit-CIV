#ifndef NITF_WINDOWSLARGEFILEREADER_H
#define NITF_WINDOWSLARGEFILEREADER_H

#include <iostream>
#include <fstream>

#include "DataReader.h"

#include "windows.h"

using namespace std;

class WindowsLargeFileReader : public DataReader{
private:
	HANDLE fHandle;
	DWORD numBytesRead;

public:
	WindowsLargeFileReader(string);
	~WindowsLargeFileReader();

	void read(unsigned char*, long long);
	void seek(long long, STARTING_POINT);
	long long tell();
	bool eof();
	long long count();
};

#endif