#ifndef NITF_RPC00B_H
#define NITF_RPC00B_H

#include <string>
#include "Extension.h"

#include <iostream>
#include <limits>

using namespace std;


class RPC00B : public Extension{
private:
	void readTags();
	void initializeTags();

	int SUCCESS_LENGTH;
	int ERR_BIAS_LENGTH;
	int ERR_RAND_LENGTH;
	int LINE_OFF_LENGTH;
	int SAMP_OFF_LENGTH;
	int LAT_OFF_LENGTH;
	int LONG_OFF_LENGTH;
	int HEIGHT_OFF_LENGTH;
	int LINE_SCALE_LENGTH;
	int SAMP_SCALE_LENGTH;
	int LAT_SCALE_LENGTH;
	int LONG_SCALE_LENGTH;
	int HEIGHT_SCALE_LENGTH;
	int LINE_NUM_COEFF_LENGTH;
	int LINE_DEN_COEFF_LENGTH;
	int SAMP_NUM_COEFF_LENGTH;
	int SAMP_DEN_COEFF_LENGTH;
public:
	RPC00B();
	RPC00B(string treTag, int treLength, string treData);
	RPC00B(const RPC00B &extension);
	RPC00B(const RPC00B *const extension);
	virtual ~RPC00B();

	virtual Extension* copy();
	void printTags();
	void writeTags();
	string getTagsAsString();

	//void writeErrBias(ostream& os, double errBias);
	//void writeErrRand(ostream& os, double errRand);
	//void writeDecimal(ostream& os, int length, bool showSign, int precision, double v);


	//void writeGeoLatOff(ostream& os, double lat_off);
	//void writeGeoLonOff(ostream& os, double lon_off);

	//void write

	static bool writeDecimal(ostream& os, int length, 
							bool showPosSign, int precision,
							double var,
							double min, 
							double max);

	static bool writeCoeff(ostream& os, int length,
							bool showPosSign, int precision,
							double var,
							double min, 
						    double max);


	bool success;
	double err_bias;
	double err_rand;
	int line_off;
	int samp_off;
	double lat_off;
	double long_off;
	int height_off;
	int line_scale;
	int samp_scale;
	double lat_scale;
	double long_scale;
	int height_scale;
	double *line_num_coeff;
	double *line_den_coeff;
	double *samp_num_coeff;
	double *samp_den_coeff;
};

#endif