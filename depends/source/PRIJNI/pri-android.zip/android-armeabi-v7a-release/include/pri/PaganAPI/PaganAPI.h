#ifndef PAGAN_API_H
#define PAGAN_API_H

// #include this in the DLL and in any EXE that uses it

#include <iostream>
#include <vector>
#include "GeoQuad.h"
#include "PixelCoordinate.h"
#include "DecimalCoordinate.h"
#include "CommonModel.h"

#include "export.h"


using namespace std;
using namespace iai;

/*
FindAllPRIs:  
Only search for files on local machine.
Given a list of files, determine which are PRI images.  Put in a list of search directories
the function will find all the images in the directories.  Then open each image and check if they
are PRI's by data extension segment.  Returns the list of files that are valid PRI images.  Returns -1 on 
failure, and/or count if successful.

Roughly similar to:  CGS code from Peter
*/
PAGAN_API_EXPORT
int FindAllPRIs(const std::vector<string>& searchDirectories, std::vector<string>& foundPRIFiles);

/*
SelectPRILocalFromCoord:  
Only search for files on local machine.
Given a lat/lon location, and a list of PRI files (Note: if they are invalid,
just ignore them), determine which PRI's have coverage over that area.

Read the NITF file, get the IGEOLO from the file, which contains the 4 corners of the image. Check if the 
point is contained in any of the images.  Return the list of images containing that point.

Roughly similar to:  CGS Java code:  PRISourceSelection.doSourceSelection().  For this project ignore
the prohibitedImages functionality.
*/
PAGAN_API_EXPORT
int SelectPRILocalFromCoord(double lat, 
							double lon,
							const std::vector<string>& searchFoundPRIFiles, 
							std::vector<string>& foundPRIs);
/*
SelectPRILocalFromBounds:  
Only search for files on local machine.
Given an area of coverage (GeoQuad), and a list of PRI files (Note: if they are invalid,
just ignore them), determine which PRI's have coverage over that area.
Don't worry about duplicates.  For now, return all images no matter how small the overlap is.
If time allows, provide an allowed overlap value to be specified.

Read the NITF file, get the IGEOLO from the file, which contains the 4 corners of the image. Check if the 
point is contained in any of the images.  Return the list of images containing that point.

Roughly similar to: CGS Java code:  PRISourceSelection.doSourceSelection().  For this project ignore
the prohibitedImages functionality (except this is for GeoQuad input.
*/
PAGAN_API_EXPORT
int SelectPRILocalFromBounds(GeoQuad bounds, 
							 const vector<string>& searchFoundPRIFiles, 
							 vector<string>& foundPRIs);
/*
GetPRIRemote:  
Talk to the PAGAN web service and download a PRI image.
Don't need to implement this at this time.

Roughly similar to:  ??  Ask Tar
*/
PAGAN_API_EXPORT
string GetPRIRemote(double lat, double lon, string url);
/*
ImageToGround:  Given a line,sample input and the name of PRI image file, return the lat/lon/elev values.

Roughly similar to: PAGAN Java I2G()
*/
PAGAN_API_EXPORT
DecimalCoordinate ImageToGround(PixelCoordinate input, string filename);
/*
GetCorners:  Given the PRI file name(Note: if file is invalid,
just ignore it), return the 4 corners of the image using the IGEOLO values.
For PRI, you can just use the 1st subheader.

Roughly similar to:
common_image com.iai.common.data.raster.formats.nitf  NITFImageSubHeader.parseIGEOLO()
*/
PAGAN_API_EXPORT
GeoQuad GetCorners(string priFile);

#endif
