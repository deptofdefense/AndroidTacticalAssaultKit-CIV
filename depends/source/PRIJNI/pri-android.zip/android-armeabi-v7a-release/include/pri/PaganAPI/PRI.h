#ifndef _PAGAN_PRI_H
#define _PAGAN_PRI_H

#if defined _WIN32
#include <windows.h>
#endif

#include <vector>

#include "NITF.h"
#include "Quad.h"
#include "newmat.h"
#include "ElevationManager.h"
#include "ErrorCoordinate.h"
#include "PixelCoordinate.h"
#include "Geometry.h"
#include "RPC00B.h"
#include "ICHIPB.h"
#include "ECEF.h"
#include "StrippedNITFReader.h"

#include "export.h"

#ifdef use_namespace
using namespace NEWMAT;
#endif
using namespace iai;

using std::vector;
using std::string;

struct PAGAN_API_EXPORT I2GResult
{
public:
    double line;
    double sample;
    double xMeters;
    double yMeters;
    double zMeters;
    double haeMeters;
    double heightSigmaMeters;
    Matrix groundCovarianceECFMetersSq;
    Matrix groundCovarianceENUMetersSq;
    double achievedPrecision;
    double ce90Meters;
    double le90Meters;
    RowVector lph;
    double latDeg;
    double lonDeg;

    I2GResult()
    {
        line = 0;
        sample = 0;
        xMeters = -999.0;
        yMeters = -999.0;
        zMeters = -999.0;
        haeMeters = -999.0;
        heightSigmaMeters = -999.0;
        groundCovarianceECFMetersSq.ReSize(3,3);  groundCovarianceECFMetersSq = 0.0;
        groundCovarianceENUMetersSq.ReSize(3,3);  groundCovarianceENUMetersSq = 0.0;
        achievedPrecision = 0.0;
        ce90Meters = -999.0;
        le90Meters = -999.0;
        lph.ReSize(3); lph = 0.0;
        latDeg = -999.0;
        lonDeg = -999.0;
    }
};

struct PAGAN_API_EXPORT PostRec
{ // used in IDW_Interpolation()
public:
    double distPixSquared; // pixel distance from interpolation point squared
    double weightedDist;  // weighted distance = 1/dist^2 -- note: this is *NOT* the final weight
    ElevationPoint post;
    DataSource::DataSource dataSource;

    PostRec()
        : distPixSquared(0.0), weightedDist(0.0), dataSource(DataSource::UNKNOWN)
    {
    };    // default constructor
    PostRec(double _distPixSquared, double _weightedDist, const ElevationPoint &_post, const DataSource::DataSource &_dataSource)
        : distPixSquared(_distPixSquared),  weightedDist(_weightedDist), post(_post), dataSource(_dataSource)
    {
    };
};

class PAGAN_API_EXPORT PRI{
private:
    string priVersion; // 1.7 or 1.12
    string dateTimeTag;

    const static double SEMI_MAJOR_AXIS;
    const static double SEMI_MINOR_AXIS;
    const static double M_PER_FT;
    const static double M2FT;
    const static double aFt;
    const static double bFt;
    const static double DLAT_MAX;
    const static double DZA_MAX;
    const static double LARGE;
    const static double flattening;
    const static double e2;
    const static double FT_PER_M;
    const static double DESIRED_PRECISION;
    const static int BLOCKSIZE;
    const static int MAX_POSTS;
    const static double SIGMA_TO_LE90;
    const static double LE90_TO_SIGMA;
    const static string ELEVATION_SEGMENT_TAG;

    // sensorElevationAngle is created in call to getGSD(),
    double sensorElevationAngle;
    
    // sensorAzRad and sensorElRad are created in call to calcGroundPoint
    double sensorAzRad;
    double sensorElRad;
    
    double meanGSD;
    double eb;
    double er;
    double Ol;
    double Os;
    double OP;
    double OL;
    double OH;
    double Sl;
    double Ss;
    double SP;
    double SL;
    double SH;

    RowVector Nl;
    RowVector Dl;
    RowVector Ns;
    RowVector Ds;

    RowVector referenceLPH;  // lat, lon, feet
    RowVector referenceXYZFeet; // all in feet
    vector<ElevationSegmentData> elevationData;

    int startVertOffset;
    int startHorzOffset;

    Quad fullQuad;
    Quad chipQuad;

    int numLines;
    int numSamples;

    bool isInitialized;

    void initialize(RPC00B* rpc, ICHIPB* ichipb, std::vector<PRIReader::PRIElevation> priElevDataVec, int numLines, int numSamples, std::string dateTimeTag);
    //void initialize(RPC00B* rpc, ICHIPB* ichipb, std::vector<PRIReader2::PRIElevation> priElevDataVec, int numLines, int numSamples, std::string dateTimeTag, std::string desshf);
    void initialize(PRIReader::NITFStat ntifStat);

    //void initialize(RPC00B* rpc, ICHIPB* ichipb,
    //                char* rawElevationData, int rawElevationDataLength,
    //                int numLines, int numSamples, std::string dateTimeTag, std::string desshf);

    void readFullQuad(ICHIPB* ichipb);
    void readChipQuad(ICHIPB* ichipb);

    vector<double> generateTransformMap(Quad to, Quad from);
    PixelCoordinate mapCoordinate(PixelCoordinate point, vector<double> coeffs);
    PixelCoordinate chip2full(PixelCoordinate point);
    PixelCoordinate full2chip(PixelCoordinate point);

    void calcGroundPoint(double line, double sample, Matrix covariance, double estimatedHeight, double heightSigma,
        double &xMeters, double &yMeters, double &zMeters,
        Matrix &groundCovarianceECFMetersSq, double achievedPrecision);
    void calcGroundPointNoProp(PixelCoordinate point,
        double estimatedHeight, double &xMeters, double &yMeters, double &zMeters,
        double &el,double achievedPrecisionMeters);
    Matrix calculateP(Matrix imageCovariance, double heightSigmaMeters);

    void getElevation(PixelCoordinate point, I2GResult &i2g);
    double getApproximateDTEDPostSpacing(ElevationSegmentData &);

    double toFeet(double meters);
    double toMeters(double feet);
    static double toRadians(double degrees) { return degrees * (3.14159265358979323846 / 180.0); }
    static double toDegrees(double radians) { return radians * (180.0 / 3.14159265358979323846); }
    static double decimetersToMeters(double decimeters){ return decimeters/10.0; }

    void calculateA_B_F_az_el(double line, double sample, double haeFeet,
        RowVector R, Matrix &A, Matrix &B, RowVector &f, double &az,
        double &el);
    vector<double> IDW_Interpolation(vector<ElevationSegmentData> &elevationData, double chipLine, double chipSample,
        int maxPosts, double searchRadiusPixels = 0);
    // void printPosts(vector<PostRec> &post);
    void savePostSorted(vector<PostRec> &sortedPost, double distPix, double weight,
        ElevationPoint &post, DataSource::DataSource &dataSource);
    static bool testForPRI(const NITF *nitf );

    // Height offset support
    iai::ECEFRay getImagingLocus(
        iai::PixelCoordinate&   imagePt,
        iai::DecimalCoordinate& groundPoint,
        double                        desiredPrecision,
        double&                       achievedPrecision);

    PixelCoordinate ecefGroundToImage(NEWMAT::RowVector ecefGroundPt);
    std::vector<double> computeGroundPartials(const NEWMAT::RowVector& groundPt) const;

    void computeWGS84PartialDerivs(double latRad, double lonRad, double htMeters, double partials[9]) const;
    static void rpcDerivatives(const NEWMAT::RowVector& numC,
                               const NEWMAT::RowVector& denomC,
                               const double x, const double y, const double z,
                               double& dx, double &dy, double &dz);
    static double deltaAngle(double angle1Rad, double angle2Rad);
    NEWMAT::RowVector getVectorToSun(ErrorCoordinate& groundPt);
    NEWMAT::RowVector getVectorToSensor(ErrorCoordinate& grountPt);
    NEWMAT::RowVector getVectorFromGroundToObject(ErrorCoordinate& groundPt,
                                                  const double& objAzDeg,
                                                  const double& objElDeg);
    NEWMAT::RowVector toECEF(PixelCoordinate pc);
    NEWMAT::RowVector toECEF(PixelCoordinate pc, double heightOverride);
    NEWMAT::RowVector calcECEF(DecimalCoordinate dc);
    NEWMAT::RowVector getUpVector(DecimalCoordinate dc);

    void parseDateString(int& year, int& month, int& day, int& hour, int& min, int& sec);

    double sunAzDeg, sunElDeg;

#if defined BUILD_PRI_SEARCH
    static std::string ws2s(const std::wstring& s);
#endif

public:
    PRI(const char *path, bool parseFullNITF = true);
    PRI(DataReader* reader);
    PRI(const PRI &pri);
    ~PRI();

    static bool isPRI(const char  *filePath);
    // unsigned char* getImageDataPointer();
    // long long getImageSize();
    double getGSD();
    bool getIsInitialized();

    I2GResult I2G(PixelCoordinate imagePoint); /* loads the elevation data */
    I2GResult I2GOverrideHeight(PixelCoordinate imagePoint, bool overrideHeight, double height);
    ErrorCoordinate imageToGroundOverrideHeight(PixelCoordinate imagePoint, bool overrideHeight, double height);

    // ----- NEW API
    ErrorCoordinate imageToGround(PixelCoordinate imagePoint);
    PixelCoordinate groundToImage(DecimalCoordinate groundPoint);
    int getWidth();
    int getHeight();

    // hieght offset
    double getHeightOffsetBaseToShadowTip(PixelCoordinate baseCoord, PixelCoordinate shadowTipCoord);
    double getHeightOffsetBaseToTop(PixelCoordinate baseCoord, PixelCoordinate topCoord);
    //double getHeightOffsetTopToShadowTip(PixelCoordinate topCoord, PixelCoordinate shadwoTipCoord);
    DecimalCoordinate getHeightOffsetTopToShadowTip(PixelCoordinate topCoord, PixelCoordinate shadwoTipCoord);

    // in case the two points selected are in different PRIs
    double getHeightOffsetBaseToShadowTip(PixelCoordinate baseCoord, PRI* shadowTipPri, PixelCoordinate shadowTipCoord);
    double getHeightOffsetBaseToTop(PixelCoordinate baseCoord, PRI* topPri, PixelCoordinate topCoord);
    //double getHeightOffsetTopToShadowTip(PixelCoordinate topCoord, PRI* shadowTipPri, PixelCoordinate shadowTipCoord);
    DecimalCoordinate getHeightOffsetTopToShadowTip(PixelCoordinate topCoord, PRI* shadowTipPri, PixelCoordinate shadowTipCoord);

    // elevation access
    double getElevation(PixelCoordinate coord);
    int getElevationSegmentDataCount();
    ElevationSegmentData &getElevationSegmentData(int idx);

    // ----- END NEW API

//the following functions are used in Windows only - for now
#if defined BUILD_PRI_SEARCH
    static void selectPRILocalFromBounds(GeoQuad& bounds,
            const LPCTSTR&  file, std::vector<string>& foundPRIs);
    static GeoQuad getCorners(const LPCTSTR& filePath);
    static void selectPRIFileFromCoord(double lat, double lon,
            const LPCTSTR&  file, std::vector<string>& foundPRIs);
    static void searchFileByPath(LPCTSTR path, std::vector<string>& foundPRIFiles);

    static std::wstring s2ws(const std::string& s);

#endif
};

#endif
