#ifndef PAGAN_ELEVATION_MANAGER_H
#define PAGAN_ELEVATION_MANAGER_H

#include <vector>
#include <string>
#include <iostream>

#include "math.h"
#include "newmat.h"

using std::vector;
using std::string;

namespace DataSource
{
    enum DataSource
    {
	    DTED0, DTED1, DTED2, SRTM, DPPDB, LIDAR, DPSS, GXP, PLATES, UNKNOWN
    };

    inline bool isDTED(DataSource source)
    {
        if (source == DTED0 || source == DTED1 || source == DTED2)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}

namespace ElevDatum
{
    enum ElevDatum {HAE, MSL84, MSL96, MSL08, AGL, UNKNOWN};

    inline bool isMSL(ElevDatum datum)
    {
        if (datum == MSL84 || datum == MSL96 || datum == MSL08)
        {
            return true;
        }
        else
        {
            return false;
        }    
    }
}

namespace ElevUnits
{
    enum ElevUnits {METERS, FEET, DECIMETERS, UNKNOWN};
}

namespace DataCompression
{
    enum DataCompression {GZIP, NOCOMPRESSION, UNKNOWN};
}

struct ElevationPoint
{
public:
    int line;
    int sample;
    // All distances stored in meters.
    double elevation;
    double ce90;
    double le90;

    ElevationPoint() :     line(0), sample(0), elevation(0.0), ce90(0.0), le90(0.0) {}
    ElevationPoint(int _line, int _sample, double _elevation, double _ce90, double _le90)
    {
        line =_line;
        sample = _sample;
        elevation = _elevation;
        ce90 = _ce90;
        le90 = _le90;
    }
    ElevationPoint(char* encoded, int baseElevation, int numBytes);

    static void feetToMeters(ElevationPoint& point);
    static void decimetersToMeters(ElevationPoint& point);
};

class ElevationSegmentData
{
private:
    bool dataChanged;
    string rawData;
    double slope90;  // Used for DPSS and PLATES only
    int dataVersion; // 0, 1, 2 for DTED; 0 for all others

public:// Header fields:
    string priCreator;
    string creatorVersion;
    DataSource::DataSource dataSource;  // 1-6
    ElevDatum::ElevDatum elevationDatum;
    ElevUnits::ElevUnits elevationUnits;
    int numElevationEntries;
    int elevationBase;
    DataCompression::DataCompression dataCompression;
    int maxSearchRadius;
    double imageAzimuth;
    int numRows;
    int numColumns;

    string desshf;
    vector<ElevationPoint> entries;

    int maxLineValue;
    int maxSampleValue;
    
    ElevationSegmentData()
    {  // constructor
        dataChanged = true;
        slope90 = -999.9;
        maxLineValue = 65535;
        maxSampleValue = 65535;

        priCreator = "IAI PRIGeneration";
        creatorVersion = "1.11";
        dataSource = DataSource::UNKNOWN;
        dataVersion = 0;
        elevationDatum = ElevDatum::UNKNOWN;
        elevationUnits = ElevUnits::UNKNOWN;
        numElevationEntries = 0;
        elevationBase = 99999;
        dataCompression = DataCompression::UNKNOWN;
        maxSearchRadius = -1;
        imageAzimuth = -1.0;
        numRows = -1;
        numColumns = -1;
    }
    
    ElevationSegmentData(DataSource::DataSource _dataSource)
    {  // constructor
        dataChanged = true;
        slope90 = -999.9;
        maxLineValue = 65535;
        maxSampleValue = 65535;

        priCreator = "IAI PRIGeneration";
        creatorVersion = "1.11";
        dataSource = _dataSource;
        dataVersion = 0;
        elevationDatum = ElevDatum::UNKNOWN;
        elevationUnits = ElevUnits::UNKNOWN;
        numElevationEntries = 0;
        elevationBase = 99999;
        dataCompression = DataCompression::UNKNOWN;
        maxSearchRadius = -1;
        imageAzimuth = -1.0;
        numRows = -1;
        numColumns = -1;
    }
    ElevationSegmentData(std::string desshfIn, char* input, int inputLength);    // constructor
    double computeSlope90(double meanGSD);// Used for DPSS and PLATES only
    int calcBaseElevation();

    int getNumberofPoints() { return entries.size(); }
    /** Returns the point at the provided index.  The order of points is arbitrary. */
    ElevationPoint& getPoint(int index) { return entries[index]; }
    int getDataVersion() { return dataVersion; }
    double getSlope90() { return slope90; }
    void setSlope90(double slp) { slope90 = slp; }

    static void saveSlopeSorted(vector<double> &sortedSlope, double slope);
    static double toDegrees(double radians) {return radians * (180.0 / 3.14159265); }
    static double round(double value);
};

int DecompressDES(char* input, int inputLength, char*& output);

#endif
