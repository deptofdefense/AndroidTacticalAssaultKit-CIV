#ifndef _STRIPPED_NITF_READER_H
#define _STRIPPED_NITF_READER_H

#include <vector>

#include "RPC00B.h"
#include "ICHIPB.h"
#include "DataReader.h"

namespace PRIReader
{
    struct PRIElevation
    {
        char* data;
        int dataLength;
        std::string desshf;

        PRIElevation()
        {
            data = NULL;
            dataLength = 0;
        }
    };

    struct NITFStat
    {
        bool isPRI;
        std::string dateTimeTag;
        int numLines;
        int numSamples;
        RPC00B* rpc;
        ICHIPB* ichipb;
        std::vector<PRIElevation> priElevDataVec;

        NITFStat()
        {
            isPRI = false;
            dateTimeTag = "19700101000000";
            numLines = 0;
            numSamples = 0;
            rpc = NULL;
            ichipb = NULL;
        }

        ~NITFStat()
        {
            //delete rpc;
            //delete ichipb;
            //for (PRIElevation pe : priElevDataVec)
            //{
            //    delete[] pe.data;
            //}
        }
    };


    bool isPRI(DataReader* source);
    void parse(DataReader* source, NITFStat& stat);
    std::string getDesshf();

}

#endif // ! _STRIPPED_NITF_READER2_
