#!/bin/sh

set -e

$(dirname $0)/../csa_common/script.sh
