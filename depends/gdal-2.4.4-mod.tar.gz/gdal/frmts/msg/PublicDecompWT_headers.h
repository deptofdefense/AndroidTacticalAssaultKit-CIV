#if ((__GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ >= 2)) && !defined(_MSC_VER))
#pragma GCC system_header
#endif

#include "PublicDecompWT/COMP/WT/Inc/CWTDecoder.h"
#include "PublicDecompWT/DISE/CDataField.h" // Util namespace
