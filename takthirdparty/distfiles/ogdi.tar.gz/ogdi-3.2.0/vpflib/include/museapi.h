#ifndef H_MUSEAPI
#define H_MUSEAPI

#ifndef H_MUSECONV
#include "museconv.h"
#endif

#ifndef H_MUSEPACY
#include "musepacy.h"
#endif

#ifndef H_MUSEPHIG
#include "musephig.h"
#endif

#ifndef H_MUSESYS
#include "musesys.h"
#endif

#ifndef H_MUSERAS
#include "museras.h"
#endif

#endif /* H_MUSEAPI */
