.. _algorithms_dsa_rst:

Digital Signature Algorithm (``DSA``)
=====================================

Known issues or limitations
---------------------------

`DSA is not yet implemented <https://github.com/rticommunity/openssl-cng-engine/issues/16>`_.
